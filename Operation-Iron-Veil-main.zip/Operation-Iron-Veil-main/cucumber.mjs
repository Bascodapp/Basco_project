export default function () {
  const common = {
    paths: ["./test/features/**/*.feature"],
    import: [
      "./test/features/support/**/*.ts",
      "./test/features/steps/**/*.ts",
    ],
    format: [
      "@cucumber/pretty-formatter",
      ["allure-cucumberjs/reporter", "/dev/null"],
    ],
    formatOptions: {
      "allure-cucumberjs/reporter": {
        resultsDir: "./allure-results",
      },
    },
    forceExit: true,
  };

  const integration = {
    tags: "@integration",
  };

  const ci = {
    tags: "@integration",
    parallel: 4,
    format: [
      "@cucumber/pretty-formatter",
      ["allure-cucumberjs/reporter", "/dev/null"],
    ],
    formatOptions: {
      "allure-cucumberjs/reporter": {
        resultsDir: "./allure-results",
      },
    },
    forceExit: true,
  };

  return {
    default: {
      ...common,
    },
    integration: {
      ...common,
      ...integration,
    },
    ci: {
      ...common,
      ...ci,
    },
  };
}
