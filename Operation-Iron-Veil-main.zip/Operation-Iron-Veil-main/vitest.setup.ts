import { beforeEach, vi } from "vitest";
import React from "react";

// Make React available globally for JSX
globalThis.React = React;

// Mock Next.js features that are commonly used in tests
vi.mock("next/navigation", () => ({
  useRouter: vi.fn(() => ({
    push: vi.fn(),
    replace: vi.fn(),
    prefetch: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    refresh: vi.fn(),
  })),
  usePathname: vi.fn(() => ""),
  useSearchParams: vi.fn(() => new URLSearchParams()),
  useParams: vi.fn(() => ({})),
}));

// Mock next/cache
vi.mock("next/cache", () => ({
  revalidatePath: vi.fn(),
  revalidateTag: vi.fn(),
}));

// Mock drizzle-orm with all commonly used exports
vi.mock("drizzle-orm", async () => {
  // Create basic mock functions for drizzle-orm operations
  const mockSql = vi.fn((strings: TemplateStringsArray, ...values: any[]) => {
    const query = {
      strings,
      values,
      raw: vi.fn((query: string) => ({ query })),
      inlineParams: vi.fn(() => ({ query: "mocked query" })),
    };
    return query;
  });

  // Add the raw method to the sql function itself
  (mockSql as any).raw = vi.fn((query: string) => ({ query }));

  return {
    sql: mockSql,
    eq: vi.fn((column: any, value: any) => ({ column, value, operator: 'eq' })),
    and: vi.fn((...conditions: any[]) => ({ conditions, operator: 'and' })),
    or: vi.fn((...conditions: any[]) => ({ conditions, operator: 'or' })),
    inArray: vi.fn((column: any, values: any[]) => ({ column, values, operator: 'inArray' })),
    isNull: vi.fn((column: any) => ({ column, operator: 'isNull' })),
    isNotNull: vi.fn((column: any) => ({ column, operator: 'isNotNull' })),
    relations: vi.fn((table: any, callback: any) => ({ table, relations: callback })),
    count: vi.fn((column?: any) => ({ column, operator: 'count' })),
    desc: vi.fn((column: any) => ({ column, operator: 'desc' })),
    asc: vi.fn((column: any) => ({ column, operator: 'asc' })),
    gte: vi.fn((column: any, value: any) => ({ column, value, operator: 'gte' })),
    lte: vi.fn((column: any, value: any) => ({ column, value, operator: 'lte' })),
    gt: vi.fn((column: any, value: any) => ({ column, value, operator: 'gt' })),
    lt: vi.fn((column: any, value: any) => ({ column, value, operator: 'lt' })),
    like: vi.fn((column: any, value: any) => ({ column, value, operator: 'like' })),
    ilike: vi.fn((column: any, value: any) => ({ column, value, operator: 'ilike' })),
    ne: vi.fn((column: any, value: any) => ({ column, value, operator: 'ne' })),
    notInArray: vi.fn((column: any, values: any[]) => ({ column, values, operator: 'notInArray' })),
    // Add other common drizzle-orm exports as needed
  };
});

// Suppress console errors during tests
const originalConsoleError = console.error;
console.error = (...args) => {
  // Uncomment to completely silence errors
  // return;

  // Filter out specific errors or pass through to original console.error
  originalConsoleError(...args);
};

// Global beforeEach for all tests
beforeEach(() => {
  vi.clearAllMocks();
});
