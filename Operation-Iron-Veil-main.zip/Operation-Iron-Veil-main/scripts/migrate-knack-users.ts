import { createClient, SupabaseClient } from "@supabase/supabase-js";
import * as fs from "fs";
import * as path from "path";
import winston from "winston"; // Import winston

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const usersJsonPath = path.join(__dirname, "users.json");
const targetCompanyName = "Holcim";
const logFilePath = path.join(__dirname, "migration-audit.log"); // Log file path

// --- Logger Setup ---
const logger = winston.createLogger({
  level: "info", // Log level (can be controlled by env var if needed)
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }), // Log stack traces for errors
    winston.format.json(), // Structured JSON format for file logging
  ),
  defaultMeta: { service: "knack-user-migration" },
  transports: [
    // Log to a file
    new winston.transports.File({ filename: logFilePath, level: "info" }),
    // Log to the console with a simpler, colored format
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple(),
        winston.format.printf(
          (info) =>
            `${info.timestamp} ${info.level}: ${info.message}` +
            (info.stack ? `\n${info.stack}` : ""),
        ),
      ),
      level: "info", // Console level can differ if desired (e.g., 'debug')
    }),
  ],
});

// Type definitions based on observed JSON structure and schema
type KnackUserName = {
  first: string;
  middle: string;
  last: string;
  title: string;
  full: string;
};

type KnackEmail = {
  email: string;
  label: string;
};

type KnackPhone = {
  area: string;
  number: string;
  ext: string | null;
  full: string;
  country: string;
  formatted: string;
};

type KnackRef = {
  id: string;
  identifier: string;
};

type KnackUserRecord = {
  id: string;
  field_4_raw: KnackUserName; // Name
  field_5_raw: KnackEmail; // Email
  field_7_raw: string; // Status (active/inactive)
  field_8_raw: string[]; // Knack Roles (profile_xx)
  field_19_raw: KnackRef[]; // Departments
  field_21_raw: KnackRef[]; // Teams
  field_319_raw: KnackPhone | ""; // Phone - Fix 1: Acknowledging it can be ""
  field_320_raw: string; // Title
};

type TeamRole = "approver" | "editor" | "lead";

const roleMapping: { [key: string]: TeamRole } = {
  "profile_44": "approver",
  "profile_43": "editor",
  "profile_28": "lead",
};

// --- Helper Functions ---

async function ensureRecordExists(
  supabase: SupabaseClient,
  tableName: string,
  matchCriteria: object,
  insertData: object,
  operationMeta: object, // Pass metadata for logging
): Promise<string | null> {
  const logMeta = { ...operationMeta, tableName, action: "ensureRecordExists" };

  try {
    const { data: existing, error: checkError } = await supabase
      .from(tableName)
      .select("id")
      .match(matchCriteria)
      .maybeSingle();

    if (checkError) {
      logger.error(
        `Error checking for existing ${tableName}`,
        {
          ...logMeta,
          status: "error",
          error: checkError.message,
          matchCriteria,
        },
      );
      return null;
    }

    if (existing) {
      // logger.info(`${tableName} record already exists`, { ...logMeta, status: 'skipped', existingId: existing.id });
      return existing.id;
    }

    const { data: inserted, error: insertError } = await supabase
      .from(tableName)
      .insert(insertData)
      .select("id")
      .single();

    if (insertError) {
      logger.error(
        `Error inserting into ${tableName}`,
        { ...logMeta, status: "error", error: insertError.message, insertData },
      );
      return null;
    }

    logger.info(
      `Created ${tableName} record`,
      { ...logMeta, status: "success", insertedId: inserted.id },
    );
    return inserted.id;
  } catch (error: any) {
    logger.error(
      `Unexpected error in ensureRecordExists for ${tableName}`,
      { ...logMeta, status: "error", error: error.message, stack: error.stack },
    );
    return null;
  }
}

// --- Main Migration Logic ---

async function migrateUsers() {
  logger.info("Migration script started.", {
    scriptPath: __filename,
    logFilePath,
    targetCompanyName,
    usersJsonPath,
  });

  if (!supabaseUrl || !supabaseServiceRoleKey) {
    logger.error(
      "Missing Supabase environment variables.",
      { variables: ["NEXT_PUBLIC_SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"] },
    );
    process.exit(1);
  }

  if (!fs.existsSync(usersJsonPath)) {
    logger.error("Users JSON file not found.", { path: usersJsonPath });
    process.exit(1);
  }

  const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  logger.info("Fetching initial data from Supabase...");

  // 1. Fetch Company ID
  let companyId: string;
  try {
    const { data: company, error: companyError } = await supabaseAdmin
      .from("companies")
      .select("id")
      .eq("name", targetCompanyName)
      .single();

    if (companyError) throw companyError;
    if (!company) throw new Error("Company not found");

    companyId = company.id;
    logger.info(
      `Found company "${targetCompanyName}"`,
      { companyId, companyName: targetCompanyName },
    );
  } catch (error: any) {
    logger.error(
      `Fatal: Could not fetch company "${targetCompanyName}"`,
      { error: error.message, stack: error.stack },
    );
    process.exit(1);
  }

  // Initialize maps
  let departmentMap = new Map<string, string>();
  let teamMap = new Map<string, { id: string; departmentId: string }>();
  let groupToDepartmentMap = new Map<string, string>();

  try {
    // 2. Fetch Departments for the company
    const { data: departmentsData, error: departmentsError } =
      await supabaseAdmin
        .from("company_departments")
        .select("id, name")
        .eq("company_id", companyId);

    if (departmentsError) throw departmentsError;

    if (!departmentsData || departmentsData.length === 0) {
      logger.warn(
        `No departments found for company. Proceeding without department/team mapping.`,
        { companyId },
      );
    } else {
      departmentMap = new Map<string, string>(
        departmentsData.map((d) => [d.name, d.id]),
      );
      const companyDepartmentIds = departmentsData.map((d) => d.id);
      logger.info(
        `Fetched departments for the company.`,
        { count: departmentMap.size, companyId },
      );

      // 3a. Fetch groups for these departments
      logger.info(
        `Fetching groups for departments...`,
        { departmentCount: companyDepartmentIds.length },
      );
      const { data: groupsData, error: groupsError } = await supabaseAdmin
        .from("groups")
        .select("id, name, department_id")
        .in("department_id", companyDepartmentIds);

      if (groupsError) throw groupsError;

      const groupCount = groupsData?.length || 0;
      logger.info(
        `Fetched groups belonging to company departments.`,
        { count: groupCount },
      );

      if (groupCount > 0) {
        const groupIds = groupsData!.map((g) => g.id);
        groupToDepartmentMap = new Map(
          groupsData!.map((g) => [g.id, g.department_id]),
        );

        // 3b. Fetch teams for these groups
        logger.info(`Fetching teams for groups...`, { groupCount });
        const { data: teamsData, error: teamsError } = await supabaseAdmin
          .from("teams")
          .select("id, name, group_id")
          .in("group_id", groupIds);

        if (teamsError) throw teamsError;

        teamMap = new Map<string, { id: string; departmentId: string }>(
          teamsData?.map((t) => {
            const departmentId = groupToDepartmentMap.get(t.group_id);
            if (!departmentId) {
              logger.warn(
                `Team found with group ID not mapped to a department.`,
                { teamId: t.id, teamName: t.name, groupId: t.group_id },
              );
            }
            return [t.name, { id: t.id, departmentId: departmentId || "" }];
          }) || [],
        );
        logger.info(
          `Fetched teams belonging to company groups.`,
          { count: teamMap.size },
        );
      }
    }
  } catch (error: any) {
    logger.error(
      "Error fetching initial departments/groups/teams data.",
      { error: error.message, stack: error.stack },
    );
    // Decide if this is fatal or if you can continue without mapping
    logger.warn(
      "Proceeding without complete team/department mapping due to fetch error.",
    );
  }

  // 4. Load Knack Users
  let knackUsers: KnackUserRecord[];
  let totalKnackRecords = 0;
  try {
    const usersJsonContent = fs.readFileSync(usersJsonPath, "utf-8");
    const knackData: { records: KnackUserRecord[] } = JSON.parse(
      usersJsonContent,
    );
    knackUsers = knackData.records;
    totalKnackRecords = knackUsers.length;
    logger.info(`Loaded Knack user records from JSON.`, {
      count: totalKnackRecords,
      path: usersJsonPath,
    });
  } catch (error: any) {
    logger.error(
      "Fatal: Could not load or parse users JSON file.",
      { path: usersJsonPath, error: error.message, stack: error.stack },
    );
    process.exit(1);
  }

  let processedCount = 0;
  let skippedInactive = 0;
  let skippedMissingData = 0;
  let userCreationSuccess = 0;
  let userCreationError = 0;
  let relationErrors = 0; // Track errors specifically during relation creation
  let generalErrors = 0; // Track unexpected errors per user

  // 5. Iterate and Migrate Users
  logger.info("Starting user processing loop...");
  for (const knackUser of knackUsers) {
    const email = knackUser.field_5_raw?.email;
    const knackUserId = knackUser.id;
    const logContext = { knackUserId, email }; // Base context for this user

    // Skip inactive users
    if (knackUser.field_7_raw !== "active") {
      skippedInactive++;
      logger.info(
        "Skipping inactive user.",
        { ...logContext, status: "skipped", reason: "inactive" },
      );
      continue;
    }

    // Basic data validation
    if (!email || !knackUser.field_4_raw?.full) {
      skippedMissingData++;
      logger.warn(
        "Skipping user due to missing email or full name.",
        {
          ...logContext,
          status: "skipped",
          reason: "missing_data",
          data: {
            hasEmail: !!email,
            hasFullName: !!knackUser.field_4_raw?.full,
          },
        },
      );
      continue;
    }

    processedCount++;
    logger.info("Processing active user.", logContext);

    const fullName = knackUser.field_4_raw.full;
    const title = knackUser.field_320_raw || null;
    const phone = typeof knackUser.field_319_raw === "object" &&
        knackUser.field_319_raw !== null
      ? knackUser.field_319_raw.formatted
      : null;

    let userId: string | null = null;
    let userProcessError = false;

    try {
      // a. Create/Invite User
      const { data: inviteData, error: inviteError } = await supabaseAdmin.auth
        .admin
        .createUser({
          email,
          password: `holcim-${email}`, // Consider a more secure temporary password strategy
          email_confirm: true, // Assuming immediate confirmation is desired
          user_metadata: { full_name: fullName, title, phone },
        });

      if (inviteError) {
        // Log the inviteError immediately when caught
        logger.error("Caught inviteError during createUser attempt.", {
          ...logContext,
          errorDetails: JSON.stringify(
            inviteError,
            Object.getOwnPropertyNames(inviteError),
          ),
        });

        // Check the specific error code instead of the message string
        if ((inviteError as any)?.code === "email_exists") {
          logger.warn(`Handling 'email_exists' error, attempting RPC...`, {
            ...logContext,
          }); // Updated log msg slightly

          // ... existing RPC try/catch block ...
          try {
            // --- Attempt using RPC function get_user_id_by_email ---
            const { data: rpcData, error: rpcError } = await supabaseAdmin
              .rpc("get_user_id_by_email", { email: email! }); // Pass email as named argument

            if (rpcError) {
              // Log RPC call error
              logger.error("RPC call failed for get_user_id_by_email.", {
                ...logContext,
                action: "rpc_get_user_id_by_email",
                status: "error",
                error: rpcError.message,
                details: rpcError.details,
                hint: rpcError.hint,
              });
              userCreationError++;
              userProcessError = true; // Keep true - failed to get ID
            } else if (!rpcData || rpcData.length === 0 || !rpcData[0]?.id) {
              // Log if RPC succeeded but returned no/invalid data
              logger.error(
                "RPC get_user_id_by_email succeeded but returned no ID.",
                {
                  ...logContext,
                  action: "rpc_get_user_id_by_email",
                  status: "error",
                  reason: "no_id_returned",
                  returnedData: rpcData, // Log what was returned for debugging
                },
              );
              userCreationError++;
              userProcessError = true; // Keep true - failed to get ID
            } else {
              // User ID found via RPC, proceed
              userId = rpcData[0].id;
              logger.info("Successfully fetched existing user ID via RPC.", {
                ...logContext,
                action: "rpc_get_user_id_by_email",
                status: "success",
                supabaseUserId: userId,
              });
              userProcessError = false; // Reset the flag - successfully got ID
              // Optional: Update metadata logic can remain here if needed
            }
          } catch (rpcCatchError: any) {
            // Catch potential synchronous errors or unexpected issues from the rpc call itself
            logger.error(
              "Exception during RPC call for get_user_id_by_email.",
              {
                ...logContext,
                action: "rpc_get_user_id_by_email",
                status: "exception",
                error: rpcCatchError.message,
                stack: rpcCatchError.stack,
              },
            );
            userCreationError++;
            userProcessError = true; // Keep true - failed to get ID
          }
          // --- End of RPC attempt ---
        } else {
          // Handle OTHER invite errors
          logger.error(
            `User creation/invite failed with unexpected error code or message.`,
            { // Updated log msg slightly
              ...logContext,
              action: "createUser",
              status: "error",
              errorCode: (inviteError as any)?.code, // Log code
              errorMessage: inviteError.message,
              errorStatus: (inviteError as any).status,
            },
          );
          userCreationError++;
          userProcessError = true; // Mark error for this user
        }
      } else if (inviteData && inviteData.user) {
        // ... success path ...
        userId = inviteData.user.id;
        logger.info(
          "User creation/invite successful.",
          {
            ...logContext,
            action: "createUser",
            status: "success",
            supabaseUserId: userId,
          },
        );
        userCreationSuccess++;
      } else {
        // ... unexpected no data case ...
        logger.error(
          "User creation/invite call succeeded but returned no user data.",
          {
            ...logContext,
            action: "createUser",
            status: "error",
            reason: "no_user_data",
          },
        );
        userCreationError++;
        userProcessError = true;
      }

      // If user creation failed OR the subsequent lookup failed, skip relations
      if (!userId) { // Simplified check
        let reason = userProcessError
          ? "user processing issue (creation or lookup failed)"
          : "userId is unexpectedly null";
        logger.warn(
          `Skipping relation creation because userId could not be determined. Reason: ${reason}`,
          { ...logContext, userProcessError },
        );
        continue; // Move to the next user
      }

      const userLogContext = { ...logContext, supabaseUserId: userId }; // Context now includes supabase ID

      // --- Determine Team Role ---
      const roleRankOrder: TeamRole[] = ["lead", "approver", "editor"];
      const knackRoles = knackUser.field_8_raw || [];
      const mappedRoles: TeamRole[] = knackRoles
        .map((role) => roleMapping[role])
        .filter((r): r is TeamRole => !!r);

      let assignedRole: TeamRole = "editor"; // Default role

      if (mappedRoles.length > 0) {
        for (const rankedRole of roleRankOrder) {
          if (mappedRoles.includes(rankedRole)) {
            assignedRole = rankedRole;
            break; // Found the highest rank, no need to check lower ranks
          }
        }
      }
      // Log the determined role for clarity, potentially before the team loop
      logger.info(`Determined highest team role for user.`, {
        ...userLogContext,
        assignedRole,
        mappedRoles,
      });

      // b. Create Company Employee Record
      const employeeResult = await ensureRecordExists(
        supabaseAdmin,
        "company_employees",
        { user_id: userId, company_id: companyId },
        { user_id: userId, company_id: companyId, role: "member" },
        { ...userLogContext, relatedTable: "company_employees" },
      );
      if (!employeeResult) relationErrors++;

      // c. Create Department Memberships
      const knackDepartments = knackUser.field_19_raw || [];
      for (const deptRef of knackDepartments) {
        const departmentId = departmentMap.get(deptRef.identifier);
        const deptLogContext = {
          ...userLogContext,
          relatedTable: "department_members",
          knackDepartmentIdentifier: deptRef.identifier,
        };
        if (departmentId) {
          const deptMemberResult = await ensureRecordExists(
            supabaseAdmin,
            "department_members",
            { user_id: userId, department_id: departmentId },
            { user_id: userId, department_id: departmentId, role: "employee" }, // Role assumption
            { ...deptLogContext, departmentId },
          );
          if (!deptMemberResult) relationErrors++;
        } else {
          relationErrors++;
          logger.warn(
            "Department identifier not found in map, skipping membership.",
            deptLogContext,
          );
        }
      }

      // d. Create Team Memberships (using the single assignedRole)
      const knackTeams = knackUser.field_21_raw || [];
      for (const teamRef of knackTeams) {
        const teamInfo = teamMap.get(teamRef.identifier);
        const teamLogContext = {
          ...userLogContext,
          relatedTable: "team_members",
          knackTeamIdentifier: teamRef.identifier,
        };

        if (teamInfo) {
          const teamMemberResult = await ensureRecordExists(
            supabaseAdmin,
            "team_members",
            { user_id: userId, team_id: teamInfo.id }, // Match criteria
            { // Use the single determined role
              user_id: userId,
              team_id: teamInfo.id,
              role: assignedRole, // Assign the single highest/default role
            },
            {
              ...teamLogContext,
              teamId: teamInfo.id,
              assignedRole: assignedRole,
            }, // Log the single role assigned
          );
          if (!teamMemberResult) relationErrors++;
        } else {
          relationErrors++;
          logger.warn(
            "Team identifier not found in map, skipping membership.",
            teamLogContext,
          );
        }
      }
    } catch (error: any) {
      generalErrors++;
      logger.error(
        "Unexpected error during user processing loop.",
        {
          ...logContext,
          supabaseUserId: userId,
          error: error.message,
          stack: error.stack,
        },
      );
    }
    // Optional: Add a small delay to avoid rate limiting
    // await new Promise(resolve => setTimeout(resolve, 50));
  } // End user loop
  logger.info("Finished user processing loop.");

  // 6. Log Summary
  const summary = {
    totalKnackRecords,
    skippedInactive,
    skippedMissingData,
    processedActiveUsers: processedCount,
    usersCreatedOrFound: userCreationSuccess,
    userCreationErrors: userCreationError,
    relationCreationErrors: relationErrors, // Errors specifically from ensureRecordExists calls
    unexpectedUserLoopErrors: generalErrors,
  };
  logger.info("--- Migration Summary ---", { summary });
  logger.info("Migration script finished.");
} // End migrateUsers function

// Run the migration
migrateUsers().catch((err) => {
  logger.error("Unhandled error during migration execution:", {
    error: err.message,
    stack: err.stack,
  });
  process.exit(1);
});
