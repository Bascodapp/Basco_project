#!/bin/bash

# ANSI color codes
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print styled messages
print_step() {
    echo -e "${BLUE}==>${NC} ${GREEN}$1${NC}"
}

print_info() {
    echo -e "${YELLOW}INFO:${NC} $1"
}

print_error() {
    echo -e "${RED}ERROR:${NC} $1"
}

# Install dependencies first
print_step "Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    print_error "Failed to install dependencies"
    exit 1
fi
print_info "Dependencies installed successfully"

# Set default to use local Supabase
USE_SUPABASE_LOCAL=true

# Check for 1Password CLI
print_step "Checking for 1Password CLI..."
if command -v op &> /dev/null; then
    print_info "1Password CLI is installed"
    
    # Define the required account and vault
    REQUIRED_ACCOUNT="tyelusconsultingllc.1password.com"
    REQUIRED_VAULT="ALOFT_DEV"
    
    # Check if user is signed in to 1Password
    CURRENT_ACCOUNT=$(op account list 2>/dev/null | grep -o "${REQUIRED_ACCOUNT}" || echo "")
    
    if [ -z "$CURRENT_ACCOUNT" ]; then
        print_info "You need to sign in to the Tyelus Consulting 1Password account"
        print_info "Attempting to sign in to ${REQUIRED_ACCOUNT}..."
        
        # Try to sign in to the specific account
        if ! op signin --account ${REQUIRED_ACCOUNT}; then
            print_error "Failed to sign in to ${REQUIRED_ACCOUNT}"
            print_info "Please run 'op signin --account ${REQUIRED_ACCOUNT}' manually and then run this script again"
            USE_SUPABASE_LOCAL=true
        else
            print_info "Successfully signed in to ${REQUIRED_ACCOUNT}"
            
            # Check if the required vault is accessible
            if ! op vault get ${REQUIRED_VAULT} &>/dev/null; then
                print_error "Cannot access the ${REQUIRED_VAULT} vault"
                print_info "You may not have access to this vault. Continuing with local Supabase setup..."
                USE_SUPABASE_LOCAL=true
            else
                print_info "Access to ${REQUIRED_VAULT} vault confirmed"
                
                # Check if .env.example exists and contains 1Password references
                if [ -f ".env.example" ] && grep -q "op://" ".env.example"; then
                    print_step "Generating .env.local from 1Password secrets..."
                    
                    # Create a temporary file to store the environment variables
                    TEMP_ENV=$(mktemp)
                    
                    # Read each line from .env.example
                    while IFS= read -r line; do
                        # Skip comments and empty lines
                        if [[ $line =~ ^#.*$ ]] || [[ -z $line ]]; then
                            echo "$line" >> "$TEMP_ENV"
                            continue
                        fi
                        
                        # Check if the line contains an op:// reference
                        if [[ $line =~ op:// ]]; then
                            # Extract the variable name and the op reference
                            VAR_NAME=$(echo "$line" | cut -d= -f1)
                            OP_REF=$(echo "$line" | cut -d= -f2)
                            
                            # Get the value from 1Password
                            SECRET_VALUE=$(op read "$OP_REF" 2>/dev/null)
                            
                            if [ $? -eq 0 ]; then
                                echo "$VAR_NAME=$SECRET_VALUE" >> "$TEMP_ENV"
                            else
                                print_error "Failed to read secret from $OP_REF"
                                echo "$line" >> "$TEMP_ENV"
                            fi
                        else
                            echo "$line" >> "$TEMP_ENV"
                        fi
                    done < ".env.example"
                    
                    # Move the temporary file to .env.local
                    mv "$TEMP_ENV" ".env.local"
                    print_info "Environment variables from 1Password have been set in .env.local"
                    
                    # Use 1Password-generated environment variables for the rest of the setup
                    USE_SUPABASE_LOCAL=false
                else
                    print_info "No 1Password references found in .env.example, will use local Supabase instance"
                    USE_SUPABASE_LOCAL=true
                fi
            fi
        fi
    else
        print_info "Already signed in to ${REQUIRED_ACCOUNT}"
        
        # Check if the required vault is accessible
        if ! op vault get ${REQUIRED_VAULT} &>/dev/null; then
            print_error "Cannot access the ${REQUIRED_VAULT} vault"
            print_info "You may not have access to this vault. Continuing with local Supabase setup..."
            USE_SUPABASE_LOCAL=true
        else
            print_info "Access to ${REQUIRED_VAULT} vault confirmed"
            
            # Check if .env.example exists and contains 1Password references
            if [ -f ".env.example" ] && grep -q "op://" ".env.example"; then
                print_step "Generating .env.local from 1Password secrets..."
                
                # Create a temporary file to store the environment variables
                TEMP_ENV=$(mktemp)
                
                # Read each line from .env.example
                while IFS= read -r line; do
                    # Skip comments and empty lines
                    if [[ $line =~ ^#.*$ ]] || [[ -z $line ]]; then
                        echo "$line" >> "$TEMP_ENV"
                        continue
                    fi
                    
                    # Check if the line contains an op:// reference
                    if [[ $line =~ op:// ]]; then
                        # Extract the variable name and the op reference
                        VAR_NAME=$(echo "$line" | cut -d= -f1)
                        OP_REF=$(echo "$line" | cut -d= -f2)
                        
                        # Get the value from 1Password
                        SECRET_VALUE=$(op read "$OP_REF" 2>/dev/null)
                        
                        if [ $? -eq 0 ]; then
                            echo "$VAR_NAME=$SECRET_VALUE" >> "$TEMP_ENV"
                        else
                            print_error "Failed to read secret from $OP_REF"
                            echo "$line" >> "$TEMP_ENV"
                        fi
                    else
                        echo "$line" >> "$TEMP_ENV"
                    fi
                done < ".env.example"
                
                # Move the temporary file to .env.local
                mv "$TEMP_ENV" ".env.local"
                print_info "Environment variables from 1Password have been set in .env.local"
                
                # Use 1Password-generated environment variables for the rest of the setup
                USE_SUPABASE_LOCAL=false
            else
                print_info "No 1Password references found in .env.example, will use local Supabase instance"
                USE_SUPABASE_LOCAL=true
            fi
        fi
    fi
else
    print_info "1Password CLI is not installed. Continuing with local Supabase setup..."
    print_info "To install 1Password CLI, visit: https://developer.1password.com/docs/cli/get-started/"
    USE_SUPABASE_LOCAL=true
fi

# Only proceed with local Supabase setup if we're not using 1Password or if explicitly requested
if [ "$USE_SUPABASE_LOCAL" = true ]; then
    # Stop any existing instances
    print_step "Cleaning up existing instances..."
    npx supabase stop || true

    # Start Supabase
    print_step "Starting Supabase..."
    npx supabase start

    # Login to Supabase
    print_step "Logging in to Supabase..."
    if ! npx supabase login --no-browser; then
        print_error "Failed to login to Supabase"
        exit 1
    fi

    # Get project credentials
    print_step "Fetching project credentials..."
    STATUS_OUTPUT=$(npx supabase status --output json)
    if [ $? -ne 0 ]; then
        print_error "Failed to get Supabase status"
        exit 1
    fi

    # Extract values using jq with the new JSON format
    SUPABASE_URL=$(echo $STATUS_OUTPUT | jq -r '.API_URL')
    ANON_KEY=$(echo $STATUS_OUTPUT | jq -r '.ANON_KEY')

    if [ "$SUPABASE_URL" == "null" ] || [ "$ANON_KEY" == "null" ]; then
        print_error "Failed to get valid credentials from Supabase"
        print_info "Raw status output:"
        echo $STATUS_OUTPUT | jq '.'  # Pretty print the JSON
        exit 1
    fi

    # Create/update .env.local
    print_step "Updating environment variables..."
    cat > .env.local << EOF
NEXT_PUBLIC_SUPABASE_URL=$SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=$ANON_KEY

# Additional Supabase configuration (optional)
SUPABASE_SERVICE_ROLE_KEY=$(echo $STATUS_OUTPUT | jq -r '.SERVICE_ROLE_KEY')
SUPABASE_JWT_SECRET=$(echo $STATUS_OUTPUT | jq -r '.JWT_SECRET')
SUPABASE_DB_URL=$(echo $STATUS_OUTPUT | jq -r '.DB_URL')

# Storage configuration
SUPABASE_STORAGE_URL=$(echo $STATUS_OUTPUT | jq -r '.STORAGE_S3_URL')
SUPABASE_S3_ACCESS_KEY=$(echo $STATUS_OUTPUT | jq -r '.S3_PROTOCOL_ACCESS_KEY_ID')
SUPABASE_S3_SECRET_KEY=$(echo $STATUS_OUTPUT | jq -r '.S3_PROTOCOL_ACCESS_KEY_SECRET')
EOF

    print_info "Environment variables have been set in .env.local"

    # Verify .env.local was created correctly
    if ! grep -q "NEXT_PUBLIC_SUPABASE_URL=$SUPABASE_URL" .env.local; then
        print_error "Failed to write environment variables correctly"
        exit 1
    fi

    # Display URLs and keys
    echo -e "\n${GREEN}Project URLs and Keys:${NC}"
    echo -e "URL: ${YELLOW}$SUPABASE_URL${NC}"
    echo -e "API Key: ${YELLOW}$ANON_KEY${NC}"
    echo -e "Studio URL: ${YELLOW}http://localhost:54423${NC}"
    echo -e "Database URL: ${YELLOW}$(echo $STATUS_OUTPUT | jq -r '.DB_URL')${NC}"

    # Verify services are running
    print_step "Verifying services..."
    curl -s "$SUPABASE_URL/health" > /dev/null
    if [ $? -eq 0 ]; then
        print_info "API is responding successfully"
    else
        print_error "API is not responding. You may need to restart the services"
    fi
fi

# Generate types (regardless of whether we're using 1Password or local Supabase)
print_step "Generating Supabase types..."
mkdir -p src/types                                                                                                                  
npx supabase gen types typescript --local --schema public > src/types/supabase.ts

# Link to remote project if PROJECT_REF is set
if [ -n "$SUPABASE_PROJECT_REF" ]; then
    print_step "Linking to remote Supabase project..."
    if npx supabase link --project-ref "$SUPABASE_PROJECT_REF"; then
        print_info "Successfully linked to remote project"
    else
        print_error "Failed to link to remote project"
        exit 1
    fi
else
    print_info "No PROJECT_REF environment variable found - skipping project linking"
fi

print_step "Setup complete! 🚀"
print_info "Environment variables have been configured"
print_info "TypeScript types have been generated"

print_info "To link this project to your Supabase project, set PROJECT_REF environment variable and run this script again"
print_info "You can find your project ref in your Supabase dashboard: https://supabase.com/dashboard/project/_/settings/general"

# Add a note about 1Password
if command -v op &> /dev/null; then
    print_info "To use 1Password for secrets management, make sure you're signed in with 'op signin --account ${REQUIRED_ACCOUNT}'"
    print_info "Then run './generate-env.sh' to generate .env.local from 1Password secrets"
fi