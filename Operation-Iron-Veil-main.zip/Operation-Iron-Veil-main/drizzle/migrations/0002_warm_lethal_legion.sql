-- Custom SQL migration file, put your code below! --

-- Enable RUM extension for improved full-text search performance
-- Note: RUM provides better ranking and ordering capabilities than GIN
-- but has slower build/insert times. Can be disabled if not available.
CREATE EXTENSION IF NOT EXISTS rum;

-- Create a generic full-text search function that can be used across any table
CREATE OR REPLACE FUNCTION generic_fts_search(
  search_text TEXT,
  tsvector_expression TEXT
) RETURNS TEXT AS $$
BEGIN
  -- Handle empty search
  IF search_text IS NULL OR trim(search_text) = '' THEN
    RETURN 'TRUE';
  END IF;
  
  -- Return the FTS condition as a string that can be used in dynamic queries
  RETURN format(
    'to_tsvector(''english'', %s) @@ plainto_tsquery(''english'', %L)',
    tsvector_expression,
    trim(search_text)
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create a helper function for common FTS field concatenation patterns
CREATE OR REPLACE FUNCTION build_fts_expression(
  fields TEXT[]
) RETURNS TEXT AS $$
BEGIN
  RETURN array_to_string(
    array(
      SELECT format('COALESCE(%s, '''')', field)
      FROM unnest(fields) AS field
    ), 
    ' || '' '' || '
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create a comprehensive FTS search function that supports multiple operators
CREATE OR REPLACE FUNCTION advanced_fts_search(
  search_text TEXT,
  tsvector_expression TEXT,
  search_type TEXT DEFAULT 'plain' -- 'plain', 'phrase', 'websearch'
) RETURNS TEXT AS $$
BEGIN
  -- Handle empty search
  IF search_text IS NULL OR trim(search_text) = '' THEN
    RETURN 'TRUE';
  END IF;
  
  -- Choose appropriate tsquery function based on search type
  CASE search_type
    WHEN 'phrase' THEN
      RETURN format(
        'to_tsvector(''english'', %s) @@ phraseto_tsquery(''english'', %L)',
        tsvector_expression,
        trim(search_text)
      );
    WHEN 'websearch' THEN
      RETURN format(
        'to_tsvector(''english'', %s) @@ websearch_to_tsquery(''english'', %L)',
        tsvector_expression,
        trim(search_text)
      );
    ELSE -- 'plain' or default
      RETURN format(
        'to_tsvector(''english'', %s) @@ plainto_tsquery(''english'', %L)',
        tsvector_expression,
        trim(search_text)
      );
  END CASE;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create a predictable prefix-based tsquery builder
CREATE OR REPLACE FUNCTION build_predictable_tsquery(search_text TEXT)
RETURNS tsquery AS $$
BEGIN
  IF search_text IS NULL OR trim(search_text) = '' THEN
    RETURN NULL;
  END IF;
  
  -- Split terms, add prefix matching, combine with AND
  RETURN to_tsquery('english', 
    array_to_string(
      array(
        SELECT trim(term) || ':*' 
        FROM unnest(string_to_array(trim(search_text), ' ')) AS term
        WHERE trim(term) != ''
      ), 
      ' & '  -- AND logic for predictable narrowing
    )
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Fallback to plainto_tsquery if query building fails
    RETURN plainto_tsquery('english', search_text);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create the main FTS search function that the application expects
-- This function returns IDs that match the search condition for use in IN clauses
CREATE OR REPLACE FUNCTION fts_search(table_name TEXT, search_condition TEXT)
RETURNS TABLE(id TEXT)
LANGUAGE plpgsql
AS $$
DECLARE
  search_query tsquery;
BEGIN
  -- Handle empty search - return all IDs
  IF search_condition IS NULL OR trim(search_condition) = '' THEN
    RETURN QUERY EXECUTE format('SELECT id::text FROM %I', table_name);
    RETURN;
  END IF;
  
  -- Build the search query using our predictable function
  search_query := build_predictable_tsquery(search_condition);
  
  -- If query building failed, return no results
  IF search_query IS NULL THEN
    RETURN;
  END IF;

  -- Execute dynamic query based on table name
  CASE table_name
    WHEN 'projects' THEN
      RETURN QUERY
      SELECT p.id::text FROM projects p
      WHERE to_tsvector('english',
        COALESCE(p.name, '') || ' ' ||
        COALESCE(p.description, '') || ' ' ||
        COALESCE(p.reason, '') || ' ' ||
        COALESCE(p.location, '') || ' ' ||
        COALESCE(p.project_source, '') || ' ' ||
        COALESCE(p.vendor_project_number, '') || ' ' ||
        COALESCE(p.id_number, '') || ' ' ||
        COALESCE(p.radar_system_number, '') || ' ' ||
        COALESCE(p.class_name, '') || ' ' ||
        COALESCE(p.cost_notes, '') || ' ' ||
        COALESCE(p.charter, '')
      ) @@ search_query;

    WHEN 'time_entries' THEN
      RETURN QUERY
      SELECT te.id::text FROM time_entries te
      WHERE to_tsvector('english',
        COALESCE(te.description, '') || ' ' ||
        COALESCE(te.rejection_reason, '')
      ) @@ search_query;

    WHEN 'time_entries_overview' THEN
      -- Enhanced search for time_entries_overview including all user-related and searchable fields
      RETURN QUERY
      SELECT te.id::text FROM time_entries te
      LEFT JOIN projects p ON te.project_id = p.id
      LEFT JOIN time_types tt ON tt.id = te.time_type_id
      LEFT JOIN instruments i ON i.id = te.instrument_id
      LEFT JOIN instruments di ON di.id = te.documentation_instrument_id
      LEFT JOIN public.profiles up ON up.user_id = te.user_id
      LEFT JOIN public.profiles ap ON ap.user_id = te.approver_id
      WHERE to_tsvector('english',
        -- Time entry fields
        COALESCE(te.description, '') || ' ' ||
        COALESCE(te.rejection_reason, '') || ' ' ||
        
        -- Project fields
        COALESCE(p.name, '') || ' ' ||
        COALESCE(p.description, '') || ' ' ||
        COALESCE(p.reason, '') || ' ' ||
        COALESCE(p.location, '') || ' ' ||
        
        -- Time type fields
        COALESCE(tt.name, '') || ' ' ||
        
        -- Instrument fields
        COALESCE(i.name, '') || ' ' ||
        COALESCE(i.type, '') || ' ' ||
        COALESCE(i.manufacturer, '') || ' ' ||
        COALESCE(i.model, '') || ' ' ||
        
        -- Documentation instrument fields
        COALESCE(di.name, '') || ' ' ||
        
        -- User fields
        COALESCE(up.email, '') || ' ' ||
        COALESCE(up.display_name, '') || ' ' ||
        COALESCE(CONCAT(up.first_name, ' ', up.last_name), '') || ' ' ||
        
        -- Approver fields
        COALESCE(ap.email, '') || ' ' ||
        COALESCE(ap.display_name, '') || ' ' ||
        COALESCE(CONCAT(ap.first_name, ' ', ap.last_name), '')
      ) @@ search_query;

    WHEN 'project_overview' THEN
      -- Enhanced search for project_overview including all searchable fields from the view
      RETURN QUERY
      SELECT DISTINCT p.id::text FROM projects p
      LEFT JOIN teams tm ON tm.id = p.team_id
      LEFT JOIN portfolio_programs prog ON prog.id = p.program_id
      LEFT JOIN company_departments d ON d.id = prog.department_id
      LEFT JOIN company_departments rd ON rd.id = p.requesting_department_id
      LEFT JOIN public.profiles creator_profile ON creator_profile.user_id = p.created_by
      LEFT JOIN public.profiles pm_profile ON pm_profile.user_id = p.project_manager_user_id
      LEFT JOIN project_sbus psbu ON psbu.project_id = p.id
      LEFT JOIN sbus sbu ON sbu.id = psbu.sbu_id
      WHERE to_tsvector('english',
        -- Core project fields
        COALESCE(p.name, '') || ' ' ||
        COALESCE(p.description, '') || ' ' ||
        COALESCE(p.status::text, '') || ' ' ||
        COALESCE(p.project_type::text, '') || ' ' ||
        COALESCE(p.classification::text, '') || ' ' ||
        COALESCE(p.priority::text, '') || ' ' ||
        COALESCE(p.reason, '') || ' ' ||
        COALESCE(p.location, '') || ' ' ||
        COALESCE(p.project_source, '') || ' ' ||
        COALESCE(p.vendor_project_number, '') || ' ' ||
        COALESCE(p.id_number, '') || ' ' ||
        COALESCE(p.radar_system_number, '') || ' ' ||
        COALESCE(p.class_name, '') || ' ' ||
        COALESCE(p.aodocs_document_id, '') || ' ' ||
        COALESCE(p.cost_notes, '') || ' ' ||
        COALESCE(p.charter, '') || ' ' ||
        
        -- Related entity fields
        COALESCE(prog.name, '') || ' ' ||
        COALESCE(tm.name, '') || ' ' ||
        COALESCE(d.name, '') || ' ' ||
        COALESCE(rd.name, '') || ' ' ||
        COALESCE(sbu.name, '') || ' ' ||
        
        -- User fields
        COALESCE(creator_profile.email, '') || ' ' ||
        COALESCE(creator_profile.display_name, '') || ' ' ||
        COALESCE(CONCAT(creator_profile.first_name, ' ', creator_profile.last_name), '') || ' ' ||
        COALESCE(pm_profile.email, '') || ' ' ||
        COALESCE(pm_profile.display_name, '') || ' ' ||
        COALESCE(CONCAT(pm_profile.first_name, ' ', pm_profile.last_name), '')
      ) @@ search_query;

    ELSE
      -- Generic fallback for other tables
      RAISE EXCEPTION 'FTS not configured for table: %', table_name;
  END CASE;
END;
$$;