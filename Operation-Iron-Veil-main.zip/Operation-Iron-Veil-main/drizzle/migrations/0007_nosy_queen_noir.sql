DROP VIEW "public"."project_overview";--> statement-breakpoint
CREATE VIEW "public"."project_overview" AS (
  SELECT 
      p.id AS project_id,
      p.name AS project_name,
      p.description AS project_description,
      p.status AS project_status,
      p.project_type AS project_type,
      p.classification AS project_classification,
      p.priority AS project_priority,
      p.reason,
      p.start_date,
      p.target_end_date,
      p.is_access_restricted,
      CASE 
          WHEN COUNT(t.id) = 0 THEN 0
          ELSE 
              ROUND(
                  (COUNT(t.id) FILTER (WHERE t.status = 'done')::DECIMAL / 
                  NULLIF(COUNT(t.id), 0)::DECIMAL) * 100
              )
      END AS completion_percentage,
      COUNT(t.id) AS task_count,
      p.team_id AS team_id,
      tm.name AS team_name,
      p.budget,
      p.business_case_dollar_value,
      prog.id AS program_id,
      prog.name AS program_name,
      prog.io_number AS program_io_number,
      prog.department_id AS owning_department_id,
      d.name AS owning_department_name,
      p.requesting_department_id AS requesting_department_id,
      rd.name AS requesting_department_name,
      p.project_manager_user_id AS project_manager_id,
      pm_user.email AS project_manager_email,
      pm_user.raw_user_meta_data->>'full_name' AS project_manager_name,
      p.created_at,
      p.updated_at,
      p.created_by AS creator_id,
      creator_user.email AS creator_email,
      creator_user.raw_user_meta_data->>'full_name' AS creator_name,
      p.preliminary_report_date,
      p.location,
      p.project_source,
      p.vendor_project_number,
      p.id_number,
      p.radar_system_number,
      p.class_name,
      p.aodocs_document_id,
      p.cost_notes,
      p.charter,
      json_agg(
        DISTINCT jsonb_build_object(
          'id', sbu.id,
          'name', sbu.name
        )
      ) FILTER (WHERE sbu.id IS NOT NULL) AS sbus,
      json_agg(
        DISTINCT jsonb_build_object(
          'id', rs.id,
          'shared_with_user_id', rs.shared_with_user_id,
          'shared_with_user_email', shared_profile.email,
          'shared_with_user_first_name', shared_profile.first_name,
          'shared_with_user_last_name', shared_profile.last_name,
          'shared_with_user_display_name', shared_profile.display_name,
          'shared_with_team_id', rs.shared_with_team_id,
          'shared_with_team_name', shared_team.name,
          'shared_with_department_id', rs.shared_with_department_id,
          'shared_with_department_name', shared_department.name
        )
      ) FILTER (
        WHERE rs.shared_with_user_id IS NOT NULL 
           OR rs.shared_with_team_id IS NOT NULL 
           OR rs.shared_with_department_id IS NOT NULL
      ) AS resource_shares
  FROM 
      projects p
  LEFT JOIN 
      project_tasks t ON t.project_id = p.id
  LEFT JOIN 
      teams tm ON tm.id = p.team_id
  LEFT JOIN 
      portfolio_programs prog ON prog.id = p.program_id
  LEFT JOIN 
      company_departments d ON d.id = prog.department_id
  LEFT JOIN 
      company_departments rd ON rd.id = p.requesting_department_id
  LEFT JOIN 
      auth.users creator_user ON creator_user.id = p.created_by
  LEFT JOIN 
      auth.users pm_user ON pm_user.id = p.project_manager_user_id
  LEFT JOIN 
      project_sbus psbu ON psbu.project_id = p.id
  LEFT JOIN 
      sbus sbu ON sbu.id = psbu.sbu_id
  LEFT JOIN 
      resource_shares rs ON rs.resource_id = p.id AND rs.resource_type = 'projects'
  LEFT JOIN 
      auth.users shared_user ON shared_user.id = rs.shared_with_user_id
  LEFT JOIN 
      teams shared_team ON shared_team.id = rs.shared_with_team_id
  LEFT JOIN 
      company_departments shared_department ON shared_department.id = rs.shared_with_department_id
  LEFT JOIN 
      public.profiles shared_profile ON shared_profile.user_id = rs.shared_with_user_id
  GROUP BY 
      p.id, 
      p.name, 
      p.description, 
      p.status,
      p.project_type,
      p.classification,
      p.priority,
      p.reason,
      p.start_date,
      p.target_end_date,
      p.is_access_restricted,
      p.budget,
      p.team_id,
      tm.name, 
      prog.id, 
      prog.name, 
      prog.department_id,
      d.name,
      rd.name,
      p.requesting_department_id,
      p.project_manager_user_id,
      pm_user.email,
      pm_user.raw_user_meta_data,
      p.created_at,
      p.updated_at,
      p.created_by,
      creator_user.email,
      creator_user.raw_user_meta_data,
      p.preliminary_report_date,
      p.location,
      p.project_source,
      p.vendor_project_number,
      p.id_number,
      p.radar_system_number,
      p.class_name,
      p.aodocs_document_id,
      p.cost_notes,
      p.charter
);