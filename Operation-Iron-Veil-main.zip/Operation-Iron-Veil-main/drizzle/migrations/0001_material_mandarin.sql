CREATE TYPE "public"."company_role" AS ENUM('company_executive', 'company_employee', 'company_contractor');--> statement-breakpoint
CREATE TYPE "public"."cost_entry_type_enum" AS ENUM('Cost Center', 'IO/Program', 'Both');--> statement-breakpoint
CREATE TYPE "public"."department_role" AS ENUM('department_head', 'department_member');--> statement-breakpoint
CREATE TYPE "public"."group_role" AS ENUM('group_lead', 'group_member');--> statement-breakpoint
CREATE TYPE "public"."issue_category_enum" AS ENUM('Supplier', 'Reformulation', 'Production', 'Performance', 'Equipment', 'Documentation');--> statement-breakpoint
CREATE TYPE "public"."note_type_enum" AS ENUM('Note', 'Update', 'Issue', 'Next Step');--> statement-breakpoint
CREATE TYPE "public"."permission_action" AS ENUM('view', 'create', 'edit', 'delete', 'approve', 'manage_members', 'assign_tasks', 'view_reports', 'manage_budget', 'archive', 'assign', 'manage', 'invite', 'remove', 'share', 'revoke');--> statement-breakpoint
CREATE TYPE "public"."portfolio_role" AS ENUM('portfolio_manager');--> statement-breakpoint
CREATE TYPE "public"."portfolio_status" AS ENUM('draft', 'active', 'on_hold', 'completed', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."pr_status_enum" AS ENUM('Draft', 'Pending Approval', 'Approved', 'Pending PO Assignment', 'PO Assigned', 'Closed', 'Cancelled', 'Rejected');--> statement-breakpoint
CREATE TYPE "public"."program_membership_role" AS ENUM('member', 'manager');--> statement-breakpoint
CREATE TYPE "public"."program_priority" AS ENUM('low', 'medium', 'high', 'urgent');--> statement-breakpoint
CREATE TYPE "public"."program_role" AS ENUM('program_manager');--> statement-breakpoint
CREATE TYPE "public"."program_status" AS ENUM('draft', 'active', 'on_hold', 'completed', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."project_priority" AS ENUM('low', 'medium', 'high', 'urgent');--> statement-breakpoint
CREATE TYPE "public"."project_role" AS ENUM('project_manager');--> statement-breakpoint
CREATE TYPE "public"."project_status" AS ENUM('pending', 'active', 'on_hold', 'closed');--> statement-breakpoint
CREATE TYPE "public"."project_type" AS ENUM('ACS Support', 'Alternative Source', 'Building Science', 'Company\Brand Change', 'Compliance', 'Cost Down', 'Customer Support (Internal & External)', 'Innovation', 'Malarkey Support', 'New Product', 'Other R&D Activities', 'Personal Holiday/Vacation', 'Product Improvement', 'Production Improvement', 'Production Support', 'RADAR', 'Raw Material and/or Private Label Support', 'Safety/Training', 'Spec/Formula/Other Res. Admin', 'Spray Foam Support', 'Stewardship Support & Reporting', 'Volunteer Hours');--> statement-breakpoint
CREATE TYPE "public"."purchase_requisition_role" AS ENUM('purchase_requisition_manager');--> statement-breakpoint
CREATE TYPE "public"."report_role" AS ENUM('report_manager');--> statement-breakpoint
CREATE TYPE "public"."resource_classification" AS ENUM('public', 'sensitive', 'confidential', 'top_secret');--> statement-breakpoint
CREATE TYPE "public"."resource_type" AS ENUM('global', 'companies', 'company_portfolios', 'portfolio_programs', 'projects', 'project_tasks', 'time_entries', 'purchase_requisitions', 'reports', 'teams', 'departments', 'company_employees', 'budgets', 'resource_shares', 'project_overview');--> statement-breakpoint
CREATE TYPE "public"."share_permission_level" AS ENUM('view', 'comment', 'edit', 'admin');--> statement-breakpoint
CREATE TYPE "public"."share_type" AS ENUM('user', 'team', 'department', 'company', 'public');--> statement-breakpoint
CREATE TYPE "public"."task_priority" AS ENUM('low', 'medium', 'high', 'urgent');--> statement-breakpoint
CREATE TYPE "public"."task_role" AS ENUM('task_manager');--> statement-breakpoint
CREATE TYPE "public"."task_status" AS ENUM('todo', 'in_progress', 'in_review', 'done', 'cancelled', 'blocked');--> statement-breakpoint
CREATE TYPE "public"."team_role" AS ENUM('team_lead', 'team_member');--> statement-breakpoint
CREATE TYPE "public"."time_entry_role" AS ENUM('time_entry_manager');--> statement-breakpoint
CREATE TYPE "public"."time_entry_status" AS ENUM('draft', 'submitted', 'approved', 'rejected');--> statement-breakpoint
CREATE TABLE "companies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"slug" text NOT NULL,
	"created_by" uuid,
	"settings" jsonb,
	"is_archived" boolean DEFAULT false,
	"archived_at" timestamp with time zone,
	"archived_by" uuid,
	"archive_reason" text,
	"retention_period_days" integer DEFAULT 365,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "companies_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
ALTER TABLE "companies" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "profiles" (
	"user_id" uuid PRIMARY KEY NOT NULL,
	"first_name" text,
	"last_name" text,
	"display_name" text,
	"email" text,
	"department" text,
	"last_selected_company_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "profiles" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "sbus" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"short_name" varchar(50)
);
--> statement-breakpoint
ALTER TABLE "sbus" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "time_types" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"requires_instrument" boolean DEFAULT false NOT NULL,
	"is_documentation_type" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "time_types" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "instruments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"type" text,
	"model" text,
	"manufacturer" text,
	"serial_number" text,
	"labor_cost_per_hour" numeric(10, 2),
	"description" text
);
--> statement-breakpoint
ALTER TABLE "instruments" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "company_departments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "company_departments" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "company_employees" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"company_id" uuid NOT NULL,
	"role" "company_role" DEFAULT 'company_employee',
	"is_active" boolean DEFAULT true,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "company_employees" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "company_sbus" (
	"company_id" uuid NOT NULL,
	"sbu_id" integer NOT NULL,
	"sequence" integer NOT NULL,
	CONSTRAINT "company_sbus_company_id_sbu_id_pk" PRIMARY KEY("company_id","sbu_id")
);
--> statement-breakpoint
ALTER TABLE "company_sbus" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "groups" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"department_id" uuid NOT NULL,
	"company_id" uuid NOT NULL,
	"group_leader_id" uuid,
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "groups" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "teams" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"company_id" uuid NOT NULL,
	"group_id" uuid NOT NULL,
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "teams" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "team_members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"team_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"created_by" uuid DEFAULT auth.uid(),
	"role" "team_role" DEFAULT 'team_member',
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "team_members" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "department_members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"department_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "department_role" DEFAULT 'department_member',
	"is_active" boolean DEFAULT true NOT NULL,
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "department_members" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "group_members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"group_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"created_by" uuid DEFAULT auth.uid(),
	"role" "group_role" DEFAULT 'group_member',
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "group_members" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "company_portfolios" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"company_id" uuid NOT NULL,
	"status" "portfolio_status" DEFAULT 'draft',
	"created_by" uuid DEFAULT auth.uid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "company_portfolios" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "portfolio_programs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"portfolio_id" uuid NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"io_number" text,
	"department_id" uuid,
	"priority" "program_priority" DEFAULT 'medium',
	"status" "program_status" DEFAULT 'draft',
	"budget" numeric(12, 2),
	"start_date" date,
	"target_end_date" date,
	"actual_end_date" date,
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "portfolio_programs" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "program_members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"program_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "program_membership_role" DEFAULT 'member',
	"created_by" uuid DEFAULT auth.uid(),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "program_members" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "projects" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"program_id" uuid NOT NULL,
	"team_id" uuid NOT NULL,
	"project_manager_user_id" uuid,
	"requesting_department_id" uuid NOT NULL,
	"name" text NOT NULL,
	"project_type" "project_type" NOT NULL,
	"classification" "resource_classification" NOT NULL,
	"description" text NOT NULL,
	"target_end_date" date,
	"priority" "project_priority",
	"budget" numeric(14, 2),
	"reason" text,
	"start_date" date,
	"preliminary_report_date" date,
	"status" "project_status" DEFAULT 'pending' NOT NULL,
	"created_by" uuid DEFAULT auth.uid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"is_access_restricted" boolean DEFAULT false NOT NULL,
	"location" text,
	"project_source" text,
	"vendor_project_number" text,
	"id_number" text,
	"radar_system_number" text,
	"class_name" text,
	"aodocs_document_id" text,
	"cost_notes" text,
	"charter" text
);
--> statement-breakpoint
ALTER TABLE "projects" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "project_tasks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"status" "task_status" DEFAULT 'todo',
	"priority" "task_priority" DEFAULT 'medium',
	"project_id" uuid NOT NULL,
	"assignee_id" uuid,
	"reporter_id" uuid NOT NULL,
	"due_date" timestamp with time zone,
	"created_by" uuid DEFAULT auth.uid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "project_tasks" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "project_sbus" (
	"project_id" uuid NOT NULL,
	"sbu_id" integer NOT NULL,
	CONSTRAINT "project_sbus_project_id_sbu_id_pk" PRIMARY KEY("project_id","sbu_id")
);
--> statement-breakpoint
ALTER TABLE "project_sbus" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "purchase_requisitions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"created_by" uuid DEFAULT auth.uid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"team_id" uuid NOT NULL,
	"entering_on_behalf_of" boolean DEFAULT false NOT NULL,
	"entered_on_behalf_of_user_id" uuid,
	"delivery_date" date NOT NULL,
	"vendor_id" uuid NOT NULL,
	"quote_proposal_number" text NOT NULL,
	"dollar_amount" numeric(12, 2) NOT NULL,
	"quote_proposal_date" date NOT NULL,
	"description" text,
	"blanket_po" boolean DEFAULT false NOT NULL,
	"cost_entry_type" "cost_entry_type_enum" NOT NULL,
	"cost_center_id" uuid,
	"program_id" uuid,
	"project_id" uuid,
	"general_ledger_number_id" uuid NOT NULL,
	"invoice_approver_user_id" uuid NOT NULL,
	"attachment_id" uuid,
	"pr_status" "pr_status_enum" DEFAULT 'Draft' NOT NULL,
	"request_title" text,
	"group" text,
	"department" text,
	"approver_ip_address" text,
	"approval_date" timestamp with time zone,
	"approved_by_user_id" uuid,
	"approver_signature" text,
	"rejection_date" timestamp with time zone,
	"rejected_by_user_id" uuid,
	"updated_since_last_rejection" boolean DEFAULT false NOT NULL,
	"po_assignment_date" timestamp with time zone,
	"po_number" text,
	"po_entered_by_user_id" uuid,
	"po_reminder_email_sent" boolean DEFAULT false NOT NULL,
	"sap_specialist_user_id" uuid,
	"sap_updated_for_close_cancel" boolean DEFAULT false NOT NULL,
	"buyer_id" uuid
);
--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "notes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" uuid NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"purchase_requisition_id" uuid NOT NULL,
	"note_type" "note_type_enum" NOT NULL,
	"title" text,
	"details" text,
	"issue_category" "issue_category_enum",
	"resolved_input" boolean DEFAULT false,
	"priority" integer,
	"due_date" date,
	"parent_note_id" uuid
);
--> statement-breakpoint
ALTER TABLE "notes" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "time_entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid DEFAULT auth.uid() NOT NULL,
	"project_id" uuid NOT NULL,
	"time_type_id" uuid NOT NULL,
	"instrument_id" uuid,
	"documentation_instrument_id" uuid,
	"date" timestamp with time zone NOT NULL,
	"start_time" timestamp with time zone NOT NULL,
	"end_time" timestamp with time zone NOT NULL,
	"total_minutes" integer NOT NULL,
	"run_count" integer,
	"description" text,
	"status" time_entry_status DEFAULT 'draft',
	"approver_id" uuid,
	"approval_date" timestamp with time zone,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "time_entries" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "timesheet_entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"timesheet_id" uuid NOT NULL,
	"time_entry_id" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "timesheet_entries_timesheet_id_time_entry_id_unique" UNIQUE("timesheet_id","time_entry_id")
);
--> statement-breakpoint
ALTER TABLE "timesheet_entries" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "timesheets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"start_date" timestamp with time zone NOT NULL,
	"end_date" timestamp with time zone NOT NULL,
	"total_minutes" integer DEFAULT 0 NOT NULL,
	"status" time_entry_status DEFAULT 'draft',
	"approver_id" uuid,
	"approval_date" timestamp with time zone,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "timesheets" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "resource_shares" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"resource_type" "resource_type" NOT NULL,
	"resource_id" uuid NOT NULL,
	"shared_with_user_id" uuid,
	"shared_with_team_id" uuid,
	"shared_with_department_id" uuid,
	"share_type" "share_type" NOT NULL,
	"permission_level" "share_permission_level" DEFAULT 'view' NOT NULL,
	"shared_by_user_id" uuid DEFAULT auth.uid() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone,
	"share_message" text,
	CONSTRAINT "unique_user_resource_share" UNIQUE("resource_type","resource_id","shared_with_user_id","share_type")
);
--> statement-breakpoint
ALTER TABLE "resource_shares" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "companies" ADD CONSTRAINT "companies_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "companies" ADD CONSTRAINT "companies_archived_by_users_id_fk" FOREIGN KEY ("archived_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "profiles" ADD CONSTRAINT "profiles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "profiles" ADD CONSTRAINT "profiles_last_selected_company_id_companies_id_fk" FOREIGN KEY ("last_selected_company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_departments" ADD CONSTRAINT "company_departments_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_departments" ADD CONSTRAINT "company_departments_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_employees" ADD CONSTRAINT "company_employees_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_employees" ADD CONSTRAINT "company_employees_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_employees" ADD CONSTRAINT "company_employees_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_sbus" ADD CONSTRAINT "company_sbus_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_sbus" ADD CONSTRAINT "company_sbus_sbu_id_sbus_id_fk" FOREIGN KEY ("sbu_id") REFERENCES "public"."sbus"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "groups" ADD CONSTRAINT "groups_department_id_company_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."company_departments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "groups" ADD CONSTRAINT "groups_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "groups" ADD CONSTRAINT "groups_group_leader_id_users_id_fk" FOREIGN KEY ("group_leader_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "groups" ADD CONSTRAINT "groups_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "teams" ADD CONSTRAINT "teams_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "teams" ADD CONSTRAINT "teams_group_id_groups_id_fk" FOREIGN KEY ("group_id") REFERENCES "public"."groups"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "teams" ADD CONSTRAINT "teams_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "team_members" ADD CONSTRAINT "team_members_team_id_teams_id_fk" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "team_members" ADD CONSTRAINT "team_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "team_members" ADD CONSTRAINT "team_members_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "department_members" ADD CONSTRAINT "department_members_department_id_company_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."company_departments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "department_members" ADD CONSTRAINT "department_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "department_members" ADD CONSTRAINT "department_members_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "group_members" ADD CONSTRAINT "group_members_group_id_groups_id_fk" FOREIGN KEY ("group_id") REFERENCES "public"."groups"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "group_members" ADD CONSTRAINT "group_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "group_members" ADD CONSTRAINT "group_members_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_portfolios" ADD CONSTRAINT "company_portfolios_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_portfolios" ADD CONSTRAINT "company_portfolios_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "portfolio_programs" ADD CONSTRAINT "portfolio_programs_portfolio_id_company_portfolios_id_fk" FOREIGN KEY ("portfolio_id") REFERENCES "public"."company_portfolios"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "portfolio_programs" ADD CONSTRAINT "portfolio_programs_department_id_company_departments_id_fk" FOREIGN KEY ("department_id") REFERENCES "public"."company_departments"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "portfolio_programs" ADD CONSTRAINT "portfolio_programs_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "program_members" ADD CONSTRAINT "program_members_program_id_portfolio_programs_id_fk" FOREIGN KEY ("program_id") REFERENCES "public"."portfolio_programs"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "program_members" ADD CONSTRAINT "program_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "program_members" ADD CONSTRAINT "program_members_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_program_id_portfolio_programs_id_fk" FOREIGN KEY ("program_id") REFERENCES "public"."portfolio_programs"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_team_id_teams_id_fk" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_project_manager_user_id_users_id_fk" FOREIGN KEY ("project_manager_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_requesting_department_id_company_departments_id_fk" FOREIGN KEY ("requesting_department_id") REFERENCES "public"."company_departments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "projects" ADD CONSTRAINT "projects_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_tasks" ADD CONSTRAINT "project_tasks_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_tasks" ADD CONSTRAINT "project_tasks_assignee_id_company_employees_id_fk" FOREIGN KEY ("assignee_id") REFERENCES "public"."company_employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_tasks" ADD CONSTRAINT "project_tasks_reporter_id_company_employees_id_fk" FOREIGN KEY ("reporter_id") REFERENCES "public"."company_employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_sbus" ADD CONSTRAINT "project_sbus_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "project_sbus" ADD CONSTRAINT "project_sbus_sbu_id_sbus_id_fk" FOREIGN KEY ("sbu_id") REFERENCES "public"."sbus"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_team_id_teams_id_fk" FOREIGN KEY ("team_id") REFERENCES "public"."teams"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_entered_on_behalf_of_user_id_users_id_fk" FOREIGN KEY ("entered_on_behalf_of_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_vendor_id_companies_id_fk" FOREIGN KEY ("vendor_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_program_id_portfolio_programs_id_fk" FOREIGN KEY ("program_id") REFERENCES "public"."portfolio_programs"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_invoice_approver_user_id_users_id_fk" FOREIGN KEY ("invoice_approver_user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_approved_by_user_id_users_id_fk" FOREIGN KEY ("approved_by_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_rejected_by_user_id_users_id_fk" FOREIGN KEY ("rejected_by_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_po_entered_by_user_id_users_id_fk" FOREIGN KEY ("po_entered_by_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_sap_specialist_user_id_users_id_fk" FOREIGN KEY ("sap_specialist_user_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "purchase_requisitions" ADD CONSTRAINT "purchase_requisitions_buyer_id_users_id_fk" FOREIGN KEY ("buyer_id") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notes" ADD CONSTRAINT "notes_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notes" ADD CONSTRAINT "notes_purchase_requisition_id_purchase_requisitions_id_fk" FOREIGN KEY ("purchase_requisition_id") REFERENCES "public"."purchase_requisitions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notes" ADD CONSTRAINT "notes_parent_note_id_notes_id_fk" FOREIGN KEY ("parent_note_id") REFERENCES "public"."notes"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "time_entries" ADD CONSTRAINT "time_entries_project_id_projects_id_fk" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "time_entries" ADD CONSTRAINT "time_entries_time_type_id_time_types_id_fk" FOREIGN KEY ("time_type_id") REFERENCES "public"."time_types"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "time_entries" ADD CONSTRAINT "time_entries_instrument_id_instruments_id_fk" FOREIGN KEY ("instrument_id") REFERENCES "public"."instruments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "time_entries" ADD CONSTRAINT "time_entries_documentation_instrument_id_instruments_id_fk" FOREIGN KEY ("documentation_instrument_id") REFERENCES "public"."instruments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "timesheet_entries" ADD CONSTRAINT "timesheet_entries_timesheet_id_timesheets_id_fk" FOREIGN KEY ("timesheet_id") REFERENCES "public"."timesheets"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "timesheet_entries" ADD CONSTRAINT "timesheet_entries_time_entry_id_time_entries_id_fk" FOREIGN KEY ("time_entry_id") REFERENCES "public"."time_entries"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "resource_shares" ADD CONSTRAINT "resource_shares_shared_with_user_id_users_id_fk" FOREIGN KEY ("shared_with_user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "resource_shares" ADD CONSTRAINT "resource_shares_shared_by_user_id_users_id_fk" FOREIGN KEY ("shared_by_user_id") REFERENCES "auth"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_companies_created_by" ON "companies" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_companies_archived_by" ON "companies" USING btree ("archived_by");--> statement-breakpoint
CREATE INDEX "idx_companies_archived" ON "companies" USING btree ("is_archived","archived_at");--> statement-breakpoint
CREATE INDEX "idx_profiles_user_id" ON "profiles" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_profiles_last_selected_company" ON "profiles" USING btree ("last_selected_company_id");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_sbus_name_unique" ON "sbus" USING btree ("name");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_time_types_name_unique" ON "time_types" USING btree ("name");--> statement-breakpoint
CREATE INDEX "instruments_name_idx" ON "instruments" USING btree ("name");--> statement-breakpoint
CREATE INDEX "instruments_type_idx" ON "instruments" USING btree ("type");--> statement-breakpoint
CREATE INDEX "instruments_manufacturer_idx" ON "instruments" USING btree ("manufacturer");--> statement-breakpoint
CREATE INDEX "dept_company_id_idx" ON "company_departments" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "dept_created_by_idx" ON "company_departments" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_company_employees_user_id" ON "company_employees" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_company_employees_company_id" ON "company_employees" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "idx_company_employees_user_company" ON "company_employees" USING btree ("user_id","company_id");--> statement-breakpoint
CREATE INDEX "idx_company_employees_company_role" ON "company_employees" USING btree ("company_id","role");--> statement-breakpoint
CREATE INDEX "idx_company_employees_user_role" ON "company_employees" USING btree ("user_id","role");--> statement-breakpoint
CREATE INDEX "idx_company_employees_created_by" ON "company_employees" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_company_employees_user_active" ON "company_employees" USING btree ("user_id","is_active") WHERE "company_employees"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_company_sbus_company_id" ON "company_sbus" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "idx_company_sbus_sbu_id" ON "company_sbus" USING btree ("sbu_id");--> statement-breakpoint
CREATE INDEX "group_department_id_idx" ON "groups" USING btree ("department_id");--> statement-breakpoint
CREATE INDEX "group_company_id_idx" ON "groups" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "group_leader_id_idx" ON "groups" USING btree ("group_leader_id");--> statement-breakpoint
CREATE INDEX "group_created_by_idx" ON "groups" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "team_company_id_idx" ON "teams" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "team_group_id_idx" ON "teams" USING btree ("group_id");--> statement-breakpoint
CREATE INDEX "team_created_by_idx" ON "teams" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_team_members_team_id" ON "team_members" USING btree ("team_id");--> statement-breakpoint
CREATE INDEX "idx_team_members_user_id" ON "team_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_team_members_user_team" ON "team_members" USING btree ("user_id","team_id");--> statement-breakpoint
CREATE INDEX "idx_team_members_team_role" ON "team_members" USING btree ("team_id","role");--> statement-breakpoint
CREATE INDEX "idx_team_members_user_role" ON "team_members" USING btree ("user_id","role");--> statement-breakpoint
CREATE INDEX "idx_team_members_created_by" ON "team_members" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_team_members_active_lookup" ON "team_members" USING btree ("team_id","user_id","is_active") WHERE "team_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_team_members_user_active" ON "team_members" USING btree ("user_id","is_active") WHERE "team_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_department_members_department_id" ON "department_members" USING btree ("department_id");--> statement-breakpoint
CREATE INDEX "idx_department_members_user_id" ON "department_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_department_members_user_dept" ON "department_members" USING btree ("user_id","department_id");--> statement-breakpoint
CREATE INDEX "idx_department_members_dept_role" ON "department_members" USING btree ("department_id","role");--> statement-breakpoint
CREATE INDEX "idx_department_members_user_role" ON "department_members" USING btree ("user_id","role");--> statement-breakpoint
CREATE INDEX "idx_department_members_created_by" ON "department_members" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_department_members_active_lookup" ON "department_members" USING btree ("department_id","user_id","is_active") WHERE "department_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_department_members_user_active" ON "department_members" USING btree ("user_id","is_active") WHERE "department_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_group_members_group_id" ON "group_members" USING btree ("group_id");--> statement-breakpoint
CREATE INDEX "idx_group_members_user_id" ON "group_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_group_members_user_group" ON "group_members" USING btree ("user_id","group_id");--> statement-breakpoint
CREATE INDEX "idx_group_members_group_role" ON "group_members" USING btree ("group_id","role");--> statement-breakpoint
CREATE INDEX "idx_group_members_user_role" ON "group_members" USING btree ("user_id","role");--> statement-breakpoint
CREATE INDEX "idx_group_members_created_by" ON "group_members" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_group_members_active_lookup" ON "group_members" USING btree ("group_id","user_id","is_active") WHERE "group_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_group_members_user_active" ON "group_members" USING btree ("user_id","is_active") WHERE "group_members"."is_active" = true;--> statement-breakpoint
CREATE INDEX "idx_company_portfolios_company_id" ON "company_portfolios" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "idx_company_portfolios_created_by" ON "company_portfolios" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_portfolio_programs_portfolio_id" ON "portfolio_programs" USING btree ("portfolio_id");--> statement-breakpoint
CREATE INDEX "idx_portfolio_programs_department_id" ON "portfolio_programs" USING btree ("department_id");--> statement-breakpoint
CREATE INDEX "idx_portfolio_programs_created_by" ON "portfolio_programs" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_program_members_program_id" ON "program_members" USING btree ("program_id");--> statement-breakpoint
CREATE INDEX "idx_program_members_user_id" ON "program_members" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_program_members_user_program" ON "program_members" USING btree ("user_id","program_id");--> statement-breakpoint
CREATE INDEX "idx_program_members_program_role" ON "program_members" USING btree ("program_id","role");--> statement-breakpoint
CREATE INDEX "idx_program_members_user_role" ON "program_members" USING btree ("user_id","role");--> statement-breakpoint
CREATE INDEX "idx_program_members_created_by" ON "program_members" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_projects_program_id" ON "projects" USING btree ("program_id");--> statement-breakpoint
CREATE INDEX "idx_projects_team_id" ON "projects" USING btree ("team_id");--> statement-breakpoint
CREATE INDEX "idx_projects_status" ON "projects" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_projects_created_by" ON "projects" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_projects_pm_user_id" ON "projects" USING btree ("project_manager_user_id");--> statement-breakpoint
CREATE INDEX "idx_project_tasks_project_id" ON "project_tasks" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "idx_project_tasks_assignee_id" ON "project_tasks" USING btree ("assignee_id");--> statement-breakpoint
CREATE INDEX "idx_project_tasks_reporter_id" ON "project_tasks" USING btree ("reporter_id");--> statement-breakpoint
CREATE INDEX "idx_project_sbus_project" ON "project_sbus" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "idx_project_sbus_sbu" ON "project_sbus" USING btree ("sbu_id");--> statement-breakpoint
CREATE INDEX "idx_pr_company_id" ON "purchase_requisitions" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "idx_pr_created_by" ON "purchase_requisitions" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_pr_team_id" ON "purchase_requisitions" USING btree ("team_id");--> statement-breakpoint
CREATE INDEX "idx_pr_vendor_id" ON "purchase_requisitions" USING btree ("vendor_id");--> statement-breakpoint
CREATE INDEX "idx_pr_program_id" ON "purchase_requisitions" USING btree ("program_id");--> statement-breakpoint
CREATE INDEX "idx_pr_project_id" ON "purchase_requisitions" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "idx_pr_status" ON "purchase_requisitions" USING btree ("pr_status");--> statement-breakpoint
CREATE INDEX "idx_pr_invoice_approver" ON "purchase_requisitions" USING btree ("invoice_approver_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_entered_on_behalf_of" ON "purchase_requisitions" USING btree ("entered_on_behalf_of_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_approved_by" ON "purchase_requisitions" USING btree ("approved_by_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_rejected_by" ON "purchase_requisitions" USING btree ("rejected_by_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_po_entered_by" ON "purchase_requisitions" USING btree ("po_entered_by_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_sap_specialist" ON "purchase_requisitions" USING btree ("sap_specialist_user_id");--> statement-breakpoint
CREATE INDEX "idx_pr_buyer" ON "purchase_requisitions" USING btree ("buyer_id");--> statement-breakpoint
CREATE INDEX "idx_note_pr_id" ON "notes" USING btree ("purchase_requisition_id");--> statement-breakpoint
CREATE INDEX "idx_note_created_by" ON "notes" USING btree ("created_by");--> statement-breakpoint
CREATE INDEX "idx_note_type" ON "notes" USING btree ("note_type");--> statement-breakpoint
CREATE INDEX "idx_note_parent_id" ON "notes" USING btree ("parent_note_id");--> statement-breakpoint
CREATE INDEX "idx_time_entries_project_id" ON "time_entries" USING btree ("project_id");--> statement-breakpoint
CREATE INDEX "idx_time_entries_user_project" ON "time_entries" USING btree ("user_id","project_id");--> statement-breakpoint
CREATE INDEX "idx_time_entries_project_status" ON "time_entries" USING btree ("project_id","status");--> statement-breakpoint
CREATE INDEX "idx_time_entries_user_date" ON "time_entries" USING btree ("user_id","date");--> statement-breakpoint
CREATE INDEX "idx_time_entries_user_status" ON "time_entries" USING btree ("user_id","status");--> statement-breakpoint
CREATE INDEX "idx_time_entries_instrument_id" ON "time_entries" USING btree ("instrument_id");--> statement-breakpoint
CREATE INDEX "idx_time_entries_documentation_instrument_id" ON "time_entries" USING btree ("documentation_instrument_id");--> statement-breakpoint
CREATE INDEX "idx_time_entries_time_type_id" ON "time_entries" USING btree ("time_type_id");--> statement-breakpoint
CREATE INDEX "idx_timesheet_entries_timesheet_id" ON "timesheet_entries" USING btree ("timesheet_id");--> statement-breakpoint
CREATE INDEX "idx_timesheet_entries_time_entry_id" ON "timesheet_entries" USING btree ("time_entry_id");--> statement-breakpoint
CREATE INDEX "idx_timesheets_user_status" ON "timesheets" USING btree ("user_id","status");--> statement-breakpoint
CREATE INDEX "idx_timesheets_approver_status" ON "timesheets" USING btree ("approver_id","status");--> statement-breakpoint
CREATE INDEX "idx_timesheets_user_dates" ON "timesheets" USING btree ("user_id","start_date","end_date");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_resource" ON "resource_shares" USING btree ("resource_type","resource_id");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_user" ON "resource_shares" USING btree ("shared_with_user_id");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_team" ON "resource_shares" USING btree ("shared_with_team_id");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_creator" ON "resource_shares" USING btree ("shared_by_user_id");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_expires_active" ON "resource_shares" USING btree ("expires_at") WHERE "resource_shares"."expires_at" IS NULL;--> statement-breakpoint
CREATE INDEX "idx_resource_shares_team_lookup" ON "resource_shares" USING btree ("shared_with_team_id","resource_type","expires_at");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_department_lookup" ON "resource_shares" USING btree ("shared_with_department_id","resource_type","expires_at");--> statement-breakpoint
CREATE INDEX "idx_resource_shares_user_lookup" ON "resource_shares" USING btree ("shared_with_user_id","resource_type","expires_at");--> statement-breakpoint
CREATE VIEW "public"."department_programs" AS (
  SELECT 
      d.id AS department_id,
      d.name AS department_name,
      
      -- Program counts
      COUNT(DISTINCT p.id) AS total_programs,
      COUNT(DISTINCT CASE WHEN p.status = 'completed' THEN p.id END) AS completed_programs,
      COUNT(DISTINCT CASE WHEN p.status = 'active' THEN p.id END) AS active_programs,
      
      -- Budget summaries (from projects)
      SUM(proj.budget) AS total_budget,
      SUM(CASE WHEN p.status = 'active' THEN proj.budget ELSE 0 END) AS active_budget,
      
      -- Project metrics
      COUNT(DISTINCT proj.id) AS total_projects,
      
      -- Task metrics
      COUNT(DISTINCT t.id) AS total_tasks,
      COUNT(DISTINCT CASE WHEN t.status = 'done' THEN t.id END) AS completed_tasks,
      
      -- Calculate overall completion percentage
      CASE 
          WHEN COUNT(DISTINCT p.id) = 0 THEN 0
          ELSE 
              ROUND(
                  (COUNT(DISTINCT CASE WHEN p.status = 'completed' THEN p.id END)::DECIMAL / 
                  COUNT(DISTINCT p.id)::DECIMAL) * 100
              )
      END AS completion_percentage,
      
      -- Metadata
      MAX(p.updated_at) AS last_updated
  FROM 
      company_departments d
  LEFT JOIN 
      portfolio_programs p ON p.department_id = d.id
  LEFT JOIN 
      projects proj ON proj.program_id = p.id
  LEFT JOIN 
      project_tasks t ON t.project_id = proj.id
  GROUP BY 
      d.id,
      d.name
);--> statement-breakpoint
CREATE VIEW "public"."portfolio_overview" AS (
  SELECT 
      p.id AS portfolio_id,
      p.name AS portfolio_name,
      p.description AS portfolio_description,
      p.status AS portfolio_status,
      p.company_id,
      c.name AS company_name,
      -- Calculate completion percentage based on programs within the portfolio
      CASE 
          WHEN COUNT(prg.id) = 0 THEN 0
          ELSE 
              ROUND(
                  (COUNT(prg.id) FILTER (WHERE prg.status = 'completed')::DECIMAL / 
                  NULLIF(COUNT(prg.id), 0)::DECIMAL) * 100
              )
      END AS completion_percentage,
      -- Count of programs per portfolio
      COUNT(prg.id) AS program_count,
      -- Get budget information (sum from projects)
      SUM(proj.budget) AS total_budget,
      -- Add metadata
      p.created_at,
      p.updated_at,
      p.created_by AS created_by,
      u.email AS creator_email
  FROM 
      company_portfolios p
  LEFT JOIN 
      companies c ON c.id = p.company_id
  LEFT JOIN 
      portfolio_programs prg ON prg.portfolio_id = p.id
  LEFT JOIN
      projects proj ON proj.program_id = prg.id
  LEFT JOIN 
      auth.users u ON u.id = p.created_by
  GROUP BY 
      p.id, 
      p.name, 
      p.description, 
      p.status, 
      p.company_id,
      c.name,
      p.created_at,
      p.updated_at,
      p.created_by,
      u.email
);--> statement-breakpoint
CREATE VIEW "public"."program_overview" AS (
  SELECT 
      p.id AS program_id,
      p.name AS program_name,
      p.description AS program_description,
      p.status AS program_status,
      
      -- Count of projects in the program
      COUNT(DISTINCT proj.id) AS project_count,
      
      -- Count of tasks across all projects in the program
      COUNT(DISTINCT t.id) AS task_count,
      
      -- Total budget (sum of project budgets)
      SUM(proj.budget) AS total_budget,
      
      -- Program priority
      p.priority AS program_priority,
      
      -- Department info
      d.id AS department_id,
      d.name AS department_name,
      
      -- Portfolio info
      port.id AS portfolio_id,
      port.name AS portfolio_name,
      
      -- Metadata
      p.created_at,
      p.updated_at,
      p.created_by AS creator_id,
      u.email AS creator_email
  FROM 
      portfolio_programs p
  LEFT JOIN 
      projects proj ON proj.program_id = p.id
  LEFT JOIN 
      project_tasks t ON t.project_id = proj.id
  LEFT JOIN 
      company_departments d ON d.id = p.department_id
  LEFT JOIN 
      company_portfolios port ON port.id = p.portfolio_id
  LEFT JOIN 
      auth.users u ON u.id = p.created_by
  GROUP BY 
      p.id, 
      p.name, 
      p.description, 
      p.status,
      p.priority,
      d.id, 
      d.name,
      port.id,
      port.name,
      p.created_at,
      p.updated_at,
      p.created_by,
      u.email
);--> statement-breakpoint
CREATE VIEW "public"."project_overview" AS (
  SELECT 
      p.id AS project_id,
      p.name AS project_name,
      p.description AS project_description,
      p.status AS project_status,
      p.project_type AS project_type,
      p.classification AS project_classification,
      p.priority AS project_priority,
      p.reason,
      p.start_date,
      p.target_end_date,
      p.is_access_restricted,
      CASE 
          WHEN COUNT(t.id) = 0 THEN 0
          ELSE 
              ROUND(
                  (COUNT(t.id) FILTER (WHERE t.status = 'done')::DECIMAL / 
                  NULLIF(COUNT(t.id), 0)::DECIMAL) * 100
              )
      END AS completion_percentage,
      COUNT(t.id) AS task_count,
      p.team_id AS team_id,
      tm.name AS team_name,
      p.budget,
      prog.id AS program_id,
      prog.name AS program_name,
      prog.department_id AS owning_department_id,
      d.name AS owning_department_name,
      p.requesting_department_id AS requesting_department_id,
      rd.name AS requesting_department_name,
      p.project_manager_user_id AS project_manager_id,
      pm_user.email AS project_manager_email,
      pm_user.raw_user_meta_data->>'full_name' AS project_manager_name,
      p.created_at,
      p.updated_at,
      p.created_by AS creator_id,
      creator_user.email AS creator_email,
      creator_user.raw_user_meta_data->>'full_name' AS creator_name,
      p.preliminary_report_date,
      p.location,
      p.project_source,
      p.vendor_project_number,
      p.id_number,
      p.radar_system_number,
      p.class_name,
      p.aodocs_document_id,
      p.cost_notes,
      p.charter,
      json_agg(
        DISTINCT jsonb_build_object(
          'id', sbu.id,
          'name', sbu.name
        )
      ) FILTER (WHERE sbu.id IS NOT NULL) AS sbus,
      json_agg(
        DISTINCT jsonb_build_object(
          'id', rs.id,
          'shared_with_user_id', rs.shared_with_user_id,
          'shared_with_user_email', shared_profile.email,
          'shared_with_user_first_name', shared_profile.first_name,
          'shared_with_user_last_name', shared_profile.last_name,
          'shared_with_user_display_name', shared_profile.display_name,
          'shared_with_team_id', rs.shared_with_team_id,
          'shared_with_team_name', shared_team.name,
          'shared_with_department_id', rs.shared_with_department_id,
          'shared_with_department_name', shared_department.name
        )
      ) FILTER (
        WHERE rs.shared_with_user_id IS NOT NULL 
           OR rs.shared_with_team_id IS NOT NULL 
           OR rs.shared_with_department_id IS NOT NULL
      ) AS resource_shares
  FROM 
      projects p
  LEFT JOIN 
      project_tasks t ON t.project_id = p.id
  LEFT JOIN 
      teams tm ON tm.id = p.team_id
  LEFT JOIN 
      portfolio_programs prog ON prog.id = p.program_id
  LEFT JOIN 
      company_departments d ON d.id = prog.department_id
  LEFT JOIN 
      company_departments rd ON rd.id = p.requesting_department_id
  LEFT JOIN 
      auth.users creator_user ON creator_user.id = p.created_by
  LEFT JOIN 
      auth.users pm_user ON pm_user.id = p.project_manager_user_id
  LEFT JOIN 
      project_sbus psbu ON psbu.project_id = p.id
  LEFT JOIN 
      sbus sbu ON sbu.id = psbu.sbu_id
  LEFT JOIN 
      resource_shares rs ON rs.resource_id = p.id AND rs.resource_type = 'projects'
  LEFT JOIN 
      auth.users shared_user ON shared_user.id = rs.shared_with_user_id
  LEFT JOIN 
      teams shared_team ON shared_team.id = rs.shared_with_team_id
  LEFT JOIN 
      company_departments shared_department ON shared_department.id = rs.shared_with_department_id
  LEFT JOIN 
      public.profiles shared_profile ON shared_profile.user_id = rs.shared_with_user_id
  GROUP BY 
      p.id, 
      p.name, 
      p.description, 
      p.status,
      p.project_type,
      p.classification,
      p.priority,
      p.reason,
      p.start_date,
      p.target_end_date,
      p.is_access_restricted,
      p.budget,
      p.team_id,
      tm.name, 
      prog.id, 
      prog.name, 
      prog.department_id,
      d.name,
      rd.name,
      p.requesting_department_id,
      p.project_manager_user_id,
      pm_user.email,
      pm_user.raw_user_meta_data,
      p.created_at,
      p.updated_at,
      p.created_by,
      creator_user.email,
      creator_user.raw_user_meta_data,
      p.preliminary_report_date,
      p.location,
      p.project_source,
      p.vendor_project_number,
      p.id_number,
      p.radar_system_number,
      p.class_name,
      p.aodocs_document_id,
      p.cost_notes,
      p.charter
);--> statement-breakpoint
CREATE VIEW "public"."time_entries_overview" AS (
  SELECT 
      te.id,
      te.user_id,
      te.project_id,
      te.time_type_id,
      te.instrument_id,
      te.documentation_instrument_id,
      te.date,
      te.start_time,
      te.end_time,
      te.total_minutes,
      te.run_count,
      te.description,
      te.status::text,
      te.approver_id,
      te.approval_date,
      te.rejection_reason,
      te.created_at,
      te.updated_at,
      
      -- Related data
      p.name AS project_name,
      tt.name AS time_type_name,
      tt.requires_instrument AS time_type_requires_instrument,
      tt.is_documentation_type AS time_type_is_documentation,
      i.name AS instrument_name,
      i.type AS instrument_type,
      i.manufacturer AS instrument_manufacturer,
      i.model AS instrument_model,
      di.name AS documentation_instrument_name,
      u.email AS user_email,
      COALESCE(
        up.display_name, 
        CONCAT(up.first_name, ' ', up.last_name),
        u.raw_user_meta_data->>'full_name',
        u.email
      ) AS user_display_name,
      au.email AS approver_email,
      COALESCE(
        ap.display_name, 
        CONCAT(ap.first_name, ' ', ap.last_name),
        au.raw_user_meta_data->>'full_name',
        au.email
      ) AS approver_display_name,
      
      -- Computed fields
      ROUND(te.total_minutes::decimal / 60, 2) AS hours
      
  FROM 
      time_entries te
  LEFT JOIN 
      projects p ON p.id = te.project_id
  LEFT JOIN 
      time_types tt ON tt.id = te.time_type_id
  LEFT JOIN 
      instruments i ON i.id = te.instrument_id
  LEFT JOIN 
      instruments di ON di.id = te.documentation_instrument_id
  LEFT JOIN 
      auth.users u ON u.id = te.user_id
  LEFT JOIN 
      public.profiles up ON up.user_id = te.user_id
  LEFT JOIN 
      auth.users au ON au.id = te.approver_id
  LEFT JOIN 
      public.profiles ap ON ap.user_id = te.approver_id
);--> statement-breakpoint
CREATE VIEW "public"."user_access_context" AS (
    SELECT 
        ce.user_id,
        ce.company_id,
        ce.role::text as company_role,
        COALESCE(array_agg(DISTINCT tm.team_id) FILTER (WHERE tm.team_id IS NOT NULL), '{}') as team_ids,
        COALESCE(array_agg(DISTINCT dm.department_id) FILTER (WHERE dm.department_id IS NOT NULL), '{}') as department_ids,
        COALESCE(array_agg(DISTINCT pm.program_id) FILTER (WHERE pm.program_id IS NOT NULL), '{}') as program_ids
    FROM company_employees ce
    LEFT JOIN team_members tm ON tm.user_id = ce.user_id
    LEFT JOIN department_members dm ON dm.user_id = ce.user_id
    LEFT JOIN program_members pm ON pm.user_id = ce.user_id
    GROUP BY ce.user_id, ce.company_id, ce.role
);--> statement-breakpoint
CREATE VIEW "public"."user_company_memberships" AS (
    SELECT 
        user_id, 
        company_id, 
        role::text
    FROM company_employees 
    WHERE user_id = auth.uid()
);--> statement-breakpoint
CREATE VIEW "public"."user_team_permissions" AS (
    SELECT 
        tm.user_id,
        tm.team_id,
        tm.role::text as team_role,
        NULL::text as resource_type,
        NULL::text as permission_role
    FROM team_members tm
    WHERE tm.user_id = auth.uid()
);--> statement-breakpoint
CREATE VIEW "public"."company_employees_with_profiles" AS (
  SELECT 
    ce.id as employee_id,
    ce.user_id,
    ce.company_id,
    ce.role,
    ce.is_active,
    ce.created_by,
    ce.created_at,
    ce.updated_at,
    p.first_name,
    p.last_name,
    p.display_name,
    p.email,
    p.department
  FROM company_employees ce
  LEFT JOIN profiles p ON p.user_id = ce.user_id
  WHERE ce.is_active = true
);--> statement-breakpoint
CREATE POLICY "companies_rule_select" ON "companies" AS PERMISSIVE FOR SELECT TO "authenticated" USING (id = (auth.jwt()->>'company_id')::uuid);--> statement-breakpoint
CREATE POLICY "companies_rule_insert" ON "companies" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "companies_rule_update" ON "companies" AS PERMISSIVE FOR UPDATE TO "authenticated" USING ((created_by = auth.uid() OR id = (auth.jwt()->>'company_id')::uuid)) WITH CHECK ((created_by = auth.uid() OR id = (auth.jwt()->>'company_id')::uuid));--> statement-breakpoint
CREATE POLICY "companies_rule_delete" ON "companies" AS PERMISSIVE FOR DELETE TO "authenticated" USING ((created_by = auth.uid() OR id = (auth.jwt()->>'company_id')::uuid));--> statement-breakpoint
CREATE POLICY "profiles_authenticated_select" ON "profiles" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "profiles_authenticated_insert" ON "profiles" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "profiles_authenticated_update" ON "profiles" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "profiles_authenticated_delete" ON "profiles" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "sbus_authenticated_select" ON "sbus" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "sbus_authenticated_insert" ON "sbus" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "sbus_authenticated_update" ON "sbus" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "sbus_authenticated_delete" ON "sbus" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "time_types_authenticated_select" ON "time_types" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "time_types_authenticated_insert" ON "time_types" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "time_types_authenticated_update" ON "time_types" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "time_types_authenticated_delete" ON "time_types" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "instruments_authenticated_select" ON "instruments" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "instruments_authenticated_insert" ON "instruments" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "instruments_authenticated_update" ON "instruments" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "instruments_authenticated_delete" ON "instruments" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_departments_authenticated_select" ON "company_departments" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_departments_authenticated_insert" ON "company_departments" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_departments_authenticated_update" ON "company_departments" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_departments_authenticated_delete" ON "company_departments" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_employees_authenticated_select" ON "company_employees" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_employees_authenticated_insert" ON "company_employees" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_employees_authenticated_update" ON "company_employees" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_employees_authenticated_delete" ON "company_employees" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_sbus_authenticated_select" ON "company_sbus" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_sbus_authenticated_insert" ON "company_sbus" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_sbus_authenticated_update" ON "company_sbus" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "company_sbus_authenticated_delete" ON "company_sbus" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "groups_authenticated_select" ON "groups" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "groups_authenticated_insert" ON "groups" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "groups_authenticated_update" ON "groups" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "groups_authenticated_delete" ON "groups" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "teams_authenticated_select" ON "teams" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "teams_authenticated_insert" ON "teams" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "teams_authenticated_update" ON "teams" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "teams_authenticated_delete" ON "teams" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "team_members_authenticated_select" ON "team_members" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "team_members_authenticated_insert" ON "team_members" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "team_members_authenticated_update" ON "team_members" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "team_members_authenticated_delete" ON "team_members" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "department_members_authenticated_select" ON "department_members" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "department_members_authenticated_insert" ON "department_members" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "department_members_authenticated_update" ON "department_members" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "department_members_authenticated_delete" ON "department_members" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "group_members_authenticated_select" ON "group_members" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "group_members_authenticated_insert" ON "group_members" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "group_members_authenticated_update" ON "group_members" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "group_members_authenticated_delete" ON "group_members" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "company_portfolios_rule_select" ON "company_portfolios" AS PERMISSIVE FOR SELECT TO "authenticated" USING (company_id = (auth.jwt()->>'company_id')::uuid);--> statement-breakpoint
CREATE POLICY "company_portfolios_rule_insert" ON "company_portfolios" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (company_id = (auth.jwt()->>'company_id')::uuid);--> statement-breakpoint
CREATE POLICY "company_portfolios_rule_update" ON "company_portfolios" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (company_id = (auth.jwt()->>'company_id')::uuid) WITH CHECK (company_id = (auth.jwt()->>'company_id')::uuid);--> statement-breakpoint
CREATE POLICY "company_portfolios_rule_delete" ON "company_portfolios" AS PERMISSIVE FOR DELETE TO "authenticated" USING (company_id = (auth.jwt()->>'company_id')::uuid);--> statement-breakpoint
CREATE POLICY "portfolio_programs_rule_select" ON "portfolio_programs" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "portfolio_programs_rule_insert" ON "portfolio_programs" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "portfolio_programs_rule_update" ON "portfolio_programs" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "portfolio_programs_rule_delete" ON "portfolio_programs" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "program_members_authenticated_select" ON "program_members" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "program_members_authenticated_insert" ON "program_members" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "program_members_authenticated_update" ON "program_members" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "program_members_authenticated_delete" ON "program_members" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "projects_rule_select" ON "projects" AS PERMISSIVE FOR SELECT TO "authenticated" USING ((created_by = auth.uid() OR project_manager_user_id = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
        )::uuid
      ) OR requesting_department_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'accessible_departments', '[]'::jsonb)
        )::uuid
      )));--> statement-breakpoint
CREATE POLICY "projects_rule_insert" ON "projects" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "projects_rule_update" ON "projects" AS PERMISSIVE FOR UPDATE TO "authenticated" USING ((created_by = auth.uid() OR project_manager_user_id = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      ))) WITH CHECK ((created_by = auth.uid() OR project_manager_user_id = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      )));--> statement-breakpoint
CREATE POLICY "projects_rule_delete" ON "projects" AS PERMISSIVE FOR DELETE TO "authenticated" USING ((created_by = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      )));--> statement-breakpoint
CREATE POLICY "project_tasks_authenticated_select" ON "project_tasks" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "project_tasks_authenticated_insert" ON "project_tasks" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "project_tasks_authenticated_update" ON "project_tasks" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "project_tasks_authenticated_delete" ON "project_tasks" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "project_sbus_authenticated_select" ON "project_sbus" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "project_sbus_authenticated_insert" ON "project_sbus" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "project_sbus_authenticated_update" ON "project_sbus" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "project_sbus_authenticated_delete" ON "project_sbus" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "purchase_requisitions_authenticated_select" ON "purchase_requisitions" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "purchase_requisitions_authenticated_insert" ON "purchase_requisitions" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "purchase_requisitions_authenticated_update" ON "purchase_requisitions" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "purchase_requisitions_authenticated_delete" ON "purchase_requisitions" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "notes_authenticated_select" ON "notes" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "notes_authenticated_insert" ON "notes" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "notes_authenticated_update" ON "notes" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "notes_authenticated_delete" ON "notes" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "time_entries_view" ON "time_entries" AS PERMISSIVE FOR SELECT TO "authenticated" USING ((
        user_id = auth.uid() OR
        project_id IN (
          SELECT p.id FROM projects p
          WHERE p.created_by = auth.uid() 
             OR p.project_manager_user_id = auth.uid()
             OR p.team_id = ANY(
               SELECT jsonb_array_elements_text(
                 COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
               )::uuid
             )
        )
      ));--> statement-breakpoint
CREATE POLICY "time_entries_create" ON "time_entries" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK ("time_entries"."user_id" = (select auth.uid()));--> statement-breakpoint
CREATE POLICY "time_entries_edit" ON "time_entries" AS PERMISSIVE FOR UPDATE TO "authenticated" USING ((
        user_id = auth.uid() AND status IN ('draft', 'rejected')
      ) OR (
        project_id IN (
          SELECT p.id FROM projects p
          WHERE p.team_id = ANY(
            SELECT jsonb_array_elements_text(
              COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
            )::uuid
          )
        )
      ));--> statement-breakpoint
CREATE POLICY "time_entries_delete" ON "time_entries" AS PERMISSIVE FOR DELETE TO "authenticated" USING ((
        user_id = auth.uid() AND status IN ('draft', 'rejected')
      ) OR (
        project_id IN (
          SELECT p.id FROM projects p
          WHERE p.team_id = ANY(
            SELECT jsonb_array_elements_text(
              COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
            )::uuid
          )
        )
      ));--> statement-breakpoint
CREATE POLICY "timesheets_authenticated_select" ON "timesheets" AS PERMISSIVE FOR SELECT TO "authenticated" USING (true);--> statement-breakpoint
CREATE POLICY "timesheets_authenticated_insert" ON "timesheets" AS PERMISSIVE FOR INSERT TO "authenticated" WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "timesheets_authenticated_update" ON "timesheets" AS PERMISSIVE FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "timesheets_authenticated_delete" ON "timesheets" AS PERMISSIVE FOR DELETE TO "authenticated" USING (true);