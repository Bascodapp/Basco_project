CREATE OR REPLACE FUNCTION public.get_user_organizational_context(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    result jsonb := '{}';
    company_data jsonb;
    department_data jsonb;
    group_data jsonb;
    team_data jsonb;
BEGIN
    -- Get company membership
    SELECT jsonb_build_object(
        'company_id', ce.company_id,
        'role', ce.role
    ) INTO company_data
    FROM company_employees ce
    WHERE ce.user_id = p_user_id 
      AND ce.is_active = true
    LIMIT 1;

    -- Get department memberships  
    SELECT COALESCE(jsonb_agg(
        jsonb_build_object(
            'department_id', dm.department_id,
            'role', dm.role
        )
    ), '[]'::jsonb) INTO department_data
    FROM department_members dm
    WHERE dm.user_id = p_user_id 
      AND dm.is_active = true;

    -- Get group memberships (direct via group_members table if it exists, or via groups.group_leader_id)
    SELECT COALESCE(jsonb_agg(
        jsonb_build_object(
            'group_id', g.id,
            'role', 'group_lead'
        )
    ), '[]'::jsonb) INTO group_data  
    FROM groups g
    WHERE g.group_leader_id = p_user_id;

    -- Get team memberships
    SELECT COALESCE(jsonb_agg(
        jsonb_build_object(
            'team_id', tm.team_id,
            'role', tm.role
        )
    ), '[]'::jsonb) INTO team_data
    FROM team_members tm
    WHERE tm.user_id = p_user_id 
      AND tm.is_active = true;

    -- Build final result
    result := jsonb_build_object(
        'company', company_data,
        'departments', department_data,
        'groups', group_data,
        'teams', team_data
    );

    RETURN result;
END;
$$;

-- =============================================================================
-- MAIN AUTH HOOK: Add Organizational Context to JWT
-- =============================================================================

CREATE OR REPLACE FUNCTION public.custom_access_token_hook(event jsonb)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    claims jsonb;
    target_user_id uuid;
    org_context jsonb;
    company_id uuid;
    scopes jsonb;
    accessible_teams uuid[];
    manageable_teams uuid[];
    accessible_departments uuid[];
    manageable_departments uuid[];
    accessible_groups uuid[];
    manageable_groups uuid[];
BEGIN
    -- Extract user_id from event
    target_user_id := (event->>'user_id')::uuid;
    
    -- Get existing claims
    claims := event->'claims';
    
    -- Get organizational context for additional claims
    SELECT get_user_organizational_context(target_user_id) INTO org_context;
    company_id := (org_context->'company'->>'company_id')::uuid;

    -- Calculate accessible teams (hierarchical)
    SELECT array_agg(DISTINCT team_id)
    INTO accessible_teams
    FROM (
        -- Direct team membership
        SELECT tm.team_id 
        FROM team_members tm 
        WHERE tm.user_id = target_user_id AND tm.is_active = true
        
        UNION
        
        -- Teams via group membership (any group role gives team access)
        SELECT t.id as team_id
        FROM group_members gm
        JOIN teams t ON t.group_id = gm.group_id
        WHERE gm.user_id = target_user_id AND gm.is_active = true
        
        UNION
        
        -- Teams via department membership (any dept role gives access to all teams in dept groups)
        SELECT t.id as team_id
        FROM department_members dm
        JOIN groups g ON g.department_id = dm.department_id
        JOIN teams t ON t.group_id = g.id
        WHERE dm.user_id = target_user_id AND dm.is_active = true
    ) all_teams;

    -- Calculate manageable teams (leadership roles only)
    SELECT array_agg(DISTINCT team_id)
    INTO manageable_teams
    FROM (
        -- Direct team leadership
        SELECT tm.team_id 
        FROM team_members tm 
        WHERE tm.user_id = target_user_id AND tm.is_active = true AND tm.role = 'team_lead'
        
        UNION
        
        -- Teams via group leadership (group_lead can manage teams in their groups)
        SELECT t.id as team_id
        FROM group_members gm
        JOIN teams t ON t.group_id = gm.group_id
        WHERE gm.user_id = target_user_id AND gm.is_active = true AND gm.role = 'group_lead'
        
        UNION
        
        -- Teams via department leadership (department_head can manage all teams in dept groups)
        SELECT t.id as team_id
        FROM department_members dm
        JOIN groups g ON g.department_id = dm.department_id
        JOIN teams t ON t.group_id = g.id
        WHERE dm.user_id = target_user_id AND dm.is_active = true AND dm.role = 'department_head'
    ) manageable_team_list;

    -- Calculate accessible departments
    SELECT array_agg(dm.department_id)
    INTO accessible_departments
    FROM department_members dm 
    WHERE dm.user_id = target_user_id AND dm.is_active = true;

    -- Calculate manageable departments
    SELECT array_agg(dm.department_id)
    INTO manageable_departments
    FROM department_members dm 
    WHERE dm.user_id = target_user_id AND dm.is_active = true AND dm.role = 'department_head';

    -- Calculate accessible groups
    SELECT array_agg(gm.group_id)
    INTO accessible_groups
    FROM group_members gm 
    WHERE gm.user_id = target_user_id AND gm.is_active = true;

    -- Calculate manageable groups
    SELECT array_agg(gm.group_id)
    INTO manageable_groups
    FROM group_members gm 
    WHERE gm.user_id = target_user_id AND gm.is_active = true AND gm.role = 'group_lead';

    -- Build contextual scopes for fast RLS policies
    scopes := jsonb_build_object(
        'accessible_teams', COALESCE(accessible_teams, '{}'),
        'manageable_teams', COALESCE(manageable_teams, '{}'),
        'accessible_departments', COALESCE(accessible_departments, '{}'),
        'manageable_departments', COALESCE(manageable_departments, '{}'),
        'accessible_groups', COALESCE(accessible_groups, '{}'),
        'manageable_groups', COALESCE(manageable_groups, '{}')
    );

    -- Add scopes to claims (no more permissions)
    claims := jsonb_set(claims, '{scopes}', scopes);
    
    -- Add organizational context to claims (useful for UI and additional checks)
    claims := jsonb_set(claims, '{company_id}', to_jsonb(company_id));
    claims := jsonb_set(claims, '{organizational_context}', org_context);

    -- Update the event with new claims
    event := jsonb_set(event, '{claims}', claims);

    RETURN event;
END;
$$;

-- =============================================================================
-- PERMISSIONS & POLICIES
-- =============================================================================

-- Grant necessary permissions to supabase_auth_admin
GRANT USAGE ON SCHEMA public TO supabase_auth_admin;

GRANT EXECUTE ON FUNCTION public.get_user_organizational_context(uuid) TO supabase_auth_admin;
GRANT EXECUTE ON FUNCTION public.custom_access_token_hook(jsonb) TO supabase_auth_admin;

-- Revoke from other roles for security
REVOKE EXECUTE ON FUNCTION public.get_user_organizational_context(uuid) FROM authenticated, anon, public;
REVOKE EXECUTE ON FUNCTION public.custom_access_token_hook(jsonb) FROM authenticated, anon, public;
