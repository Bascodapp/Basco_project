ALTER POLICY "projects_rule_update" ON "projects" TO authenticated USING ((created_by = auth.uid() OR project_manager_user_id = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      ) OR auth.jwt()->'organizational_context'->'company'->>'role' = 'company_executive')) WITH CHECK ((created_by = auth.uid() OR project_manager_user_id = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      ) OR auth.jwt()->'organizational_context'->'company'->>'role' = 'company_executive'));--> statement-breakpoint
ALTER POLICY "projects_rule_delete" ON "projects" TO authenticated USING ((created_by = auth.uid() OR team_id = ANY(
        SELECT jsonb_array_elements_text(
          COALESCE(auth.jwt()->'scopes'->'manageable_teams', '[]'::jsonb)
        )::uuid
      ) OR auth.jwt()->'organizational_context'->'company'->>'role' = 'company_executive'));