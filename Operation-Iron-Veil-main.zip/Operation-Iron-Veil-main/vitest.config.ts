import { defineConfig } from 'vitest/config'
import tsconfigPaths from 'vite-tsconfig-paths'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [
    react(),
    tsconfigPaths(),
  ],
  test: {
    // 🔧 REPORTERS CONFIGURATION - ROOT LEVEL ONLY
    // These apply to all projects and can be overridden via CLI
    reporters: ['default'],
    
    // Output files for different reporters (used when CLI overrides)
    outputFile: {
      junit: './test-results/junit.xml',
      json: './test-results/json-report.json',
      html: './test-results/html-report.html',
      allure: './allure-results',
    },

    // Global test configuration
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./vitest.setup.ts'],
    
    // 🎯 PROJECTS CONFIGURATION
    // Each project defines different test types
    projects: [
      // 🔬 Unit Tests Project
      {
        plugins: [
          tsconfigPaths(),
        ],
        test: {
          name: 'unit',
          include: ['src/**/*.{test,spec}.{ts,tsx}'],
          exclude: [
            'src/**/*.{integration,e2e,smoke}.{test,spec}.{ts,tsx}',
            '**/node_modules/**'
          ],
          environment: 'jsdom',
          globals: true,
          setupFiles: ['./vitest.setup.ts'],
        }
      },

      // 🔗 Integration Tests Project  
      {
        plugins: [
          react(),
          tsconfigPaths(),
        ],
        test: {
          name: 'integration',
          include: ['src/**/*.integration.{test,spec}.{ts,tsx}'],
          environment: 'jsdom',
          globals: true,
          setupFiles: ['./vitest.setup.ts'],
          testTimeout: 15000, // Longer timeout for integration tests
        }
      },

      // 💨 Smoke Tests Project
      {
        test: {
          name: 'smoke',
          include: ['src/**/*.smoke.{test,spec}.{ts,tsx}', 'tests/smoke/**/*.{test,spec}.{ts,tsx}'],
          environment: 'jsdom',
          globals: true,
          setupFiles: ['./vitest.setup.ts'],
          testTimeout: 10000,
        }
      }
    ],

    // Global settings that apply to all projects
    pool: 'threads',
    poolOptions: {
      threads: {
        singleThread: true // Disable for better performance if tests don't conflict
      }
    },
    
    // Coverage configuration (applies to all projects)
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: [
        'coverage/**',
        'dist/**',
        '**/node_modules/**',
        '**/*.d.ts',
        '**/*.config.*',
        '**/*.stories.*',
        'tests/**',
        '**/{test,tests,__tests__}/**',
        '**/*{.,-}{test,spec}.*',
      ]
    }
  },
}) 