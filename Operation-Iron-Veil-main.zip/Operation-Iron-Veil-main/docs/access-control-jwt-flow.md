# JWT Flow and Organizational Context

## Authentication Flow

JWT tokens are enhanced with organizational context and pre-calculated scopes for efficient authorization.

## JWT Enhancement Process

### 1. User Login
```typescript
// Standard Supabase authentication
const { data } = await supabase.auth.signInWithPassword({
  email,
  password
});
```

### 2. JWT Hook Execution
The `custom_access_token_hook` function enriches JWT with organizational data:

```sql
-- Triggered automatically on JWT generation
CREATE OR REPLACE FUNCTION public.custom_access_token_hook(event jsonb)
RETURNS jsonb
```

### 3. Organizational Context Calculation
```sql
-- Hierarchical membership calculation
SELECT get_user_organizational_context(user_id)
-- Returns: company, departments, groups, teams with roles
```

### 4. Scope Pre-calculation
JWT includes pre-calculated arrays for fast authorization:

```json
{
  "scopes": {
    "accessible_teams": ["team-1", "team-2"],
    "manageable_teams": ["team-1"],
    "accessible_departments": ["dept-1"],
    "manageable_departments": [],
    "accessible_groups": ["group-1"],
    "manageable_groups": ["group-1"]
  }
}
```

## Hierarchical Access Logic

### Team Access
```sql
-- User gets team access through:
-- 1. Direct team membership
-- 2. Group membership (any role)
-- 3. Department membership (any role)
```

### Team Management
```sql
-- User can manage teams through:
-- 1. Direct team leadership (team_lead)
-- 2. Group leadership (group_lead)
-- 3. Department leadership (department_head)
```

## JWT Claims Structure

### Standard Claims
```json
{
  "sub": "user-id",
  "exp": 1234567890,
  "iat": 1234567890
}
```

### Enhanced Claims
```json
{
  "company_id": "company-uuid",
  "organizational_context": {
    "company": {
      "company_id": "company-uuid", 
      "role": "employee"
    },
    "departments": [
      {
        "department_id": "dept-uuid",
        "role": "department_head"
      }
    ],
    "groups": [
      {
        "group_id": "group-uuid",
        "role": "group_lead"
      }
    ],
    "teams": [
      {
        "team_id": "team-uuid",
        "role": "team_member"
      }
    ]
  },
  "scopes": {
    "accessible_teams": ["team-1", "team-2"],
    "manageable_teams": ["team-1"],
    "accessible_departments": ["dept-1"],
    "manageable_departments": ["dept-1"],
    "accessible_groups": ["group-1"],
    "manageable_groups": ["group-1"]
  }
}
```

## Authorization Evaluation

### RLS Policy Evaluation
```sql
-- Uses pre-calculated scopes for performance
team_id = ANY(
  SELECT jsonb_array_elements_text(
    COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
  )::uuid
)
```

### Application Evaluation
```typescript
// Uses same JWT claims for consistency
const authContext = new JWTAuthorizationContext(jwtClaims);
const canAccess = authContext.canPerformAction('projects', 'select');
```

## Performance Optimizations

### 1. Pre-calculated Scopes
- Avoids complex joins in RLS policies
- Reduces database load during authorization
- Enables fast array membership checks

### 2. Hierarchical Flattening
- All accessible resources calculated once
- Includes inherited permissions
- Stored as flat arrays in JWT

### 3. Caching Strategy
- JWT valid for configured duration
- Organizational changes trigger re-authentication
- Balances performance vs. freshness

## Security Considerations

### JWT Size Limits
- Monitor JWT size (typically < 4KB)
- Consider scope optimization for large organizations
- Implement JWT rotation for security

### Token Refresh
- Automatic refresh on organizational changes
- Manual refresh for permission updates
- Graceful handling of expired tokens

### Defense in Depth
- RLS policies as primary security layer
- Application checks for UI/UX logic
- Both use identical authorization logic

## Troubleshooting

### Common Issues
1. **Stale JWT**: User permissions changed but JWT not refreshed
2. **Missing Scopes**: Organizational memberships not properly calculated
3. **Size Limits**: JWT too large for some systems

### Debug Commands
```sql
-- Check user's organizational context
SELECT get_user_organizational_context('user-id');

-- Verify JWT claims
SELECT auth.jwt();

-- Test scope calculation
SELECT jsonb_array_elements_text(
  COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
);
```

## Best Practices

### JWT Validation
```typescript
// Always validate JWT structure
if (!claims.company_id || !claims.organizational_context) {
  throw new Error('Invalid JWT claims');
}
```

### Scope Usage
```typescript
// Use scopes for efficient filtering
const accessibleTeams = claims.scopes.accessible_teams;
const filteredProjects = projects.filter(p => 
  accessibleTeams.includes(p.teamId)
);
```

### Error Handling
```typescript
// Handle expired or invalid JWTs
try {
  const authContext = new JWTAuthorizationContext(claims);
} catch (error) {
  // Redirect to login or refresh token
}
``` 