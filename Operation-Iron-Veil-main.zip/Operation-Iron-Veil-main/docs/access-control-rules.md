# Working with Authorization Rules

## Rule Structure

Authorization rules follow a consistent JSON schema with declarative conditions.

```json
{
  "resource": "projects",
  "action": "select",
  "description": "Users can view projects they own, manage, or have team/department access to",
  "conditions": {
    "or": [
      { "userOwns": "created_by" },
      { "userOwns": "project_manager_user_id" },
      { "userAccesses": "team_id" },
      { "userAccesses": "requesting_department_id" }
    ]
  }
}
```

## Condition Types

### Direct Ownership
```json
{ "userOwns": "field_name" }
```
- Checks if `field_name` equals `auth.uid()`
- Used for creator/owner relationships

### Access Rights
```json
{ "userAccesses": "field_name" }
```
- Checks if `field_name` is in user's accessible resources
- Uses JWT scopes: `accessible_teams`, `accessible_departments`, `accessible_groups`

### Management Rights
```json
{ "userManages": "field_name" }
```
- Checks if user has management permissions for resource
- Uses JWT scopes: `manageable_teams`, `manageable_departments`, `manageable_groups`

### Simple Conditions
```json
{ "field": "authenticated", "equals": true }
```
- Direct field comparisons
- Common for company isolation handled by parent RLS

## Logical Operators

### OR Conditions
```json
{
  "or": [
    { "userOwns": "created_by" },
    { "userManages": "team_id" }
  ]
}
```

### AND Conditions
```json
{
  "and": [
    { "field": "authenticated", "equals": true },
    { "userAccesses": "department_id" }
  ]
}
```

## Adding New Rules

### 1. Define the Rule
Add to `authorization-rules.json`:

```json
{
  "resource": "time_entries",
  "action": "select",
  "description": "Users can view time entries they created or for projects they manage",
  "conditions": {
    "or": [
      { "userOwns": "user_id" },
      { "userManages": "project_id" }
    ]
  }
}
```

### 2. Generate Policies
```bash
bun run codegen:auth-rules
```

### 3. Apply Migration
```bash
bun run db:migrate
```

## Best Practices

### Resource Hierarchy
Structure rules to respect organizational hierarchy:
- Company isolation at top level
- Department/team access for mid-level
- Individual ownership for granular control

### Performance Considerations
- Use JWT scopes for complex access checks
- Prefer `userAccesses`/`userManages` over complex joins
- Company isolation should be handled by parent resource RLS

### Security Principles
- Default deny - no conditions means no access
- Layer defense - RLS + application checks
- Principle of least privilege - grant minimum necessary access

## Common Patterns

### Creator + Manager Pattern
```json
{
  "or": [
    { "userOwns": "created_by" },
    { "userManages": "team_id" }
  ]
}
```

### Hierarchical Access
```json
{
  "or": [
    { "userOwns": "user_id" },
    { "userAccesses": "team_id" },
    { "userAccesses": "department_id" }
  ]
}
```

### Company Isolation
```json
{
  "field": "authenticated",
  "equals": true,
  "description": "Company isolation handled by parent RLS"
}
```

## Validation

Rules are validated during generation:
- Required fields: `resource`, `action`, `conditions`
- Valid condition types: `userOwns`, `userAccesses`, `userManages`, `field`
- Logical operators: `or`, `and`
- No circular dependencies 