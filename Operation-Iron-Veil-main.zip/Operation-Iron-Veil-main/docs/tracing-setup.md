# Distributed Tracing Setup with OpenTelemetry + Honeycomb

This document explains how to set up distributed tracing to debug issues like the "Creating account..." stuck state in the signup flow.

## The Problem

The signup flow was getting stuck in "Creating account..." state because:

1. ✅ User gets created in Supabase Auth (`auth.users` table)
2. ❌ Profile creation fails silently (database error)
3. ❌ Error is logged but not returned to the client
4. ⏳ UI stays in loading state indefinitely

## The Solution

We've implemented OpenTelemetry tracing with Honeycomb to:

1. **Track the complete signup flow** with detailed spans
2. **Capture errors at each step** with proper exception recording
3. **Fix the silent failure** by returning profile creation errors
4. **Provide end-to-end visibility** into the authentication process

## Environment Variables

Add these to your `.env.local`:

```bash
# OpenTelemetry Configuration
OTEL_SERVICE_NAME=aloft-app
OTEL_SDK_DISABLED=false

# Honeycomb Configuration
HONEYCOMB_API_KEY=your_honeycomb_api_key_here
HONEYCOMB_ENDPOINT=https://api.honeycomb.io/v1/traces
# HONEYCOMB_DATASET=your_dataset_name  # Only needed for Honeycomb Classic

# Database Configuration
DATABASE_URL=your_database_url_here
POSTGRES_URL=your_postgres_url_here
```

## How It Works

### 1. Instrumentation Setup

- `instrumentation.ts` - Next.js instrumentation hook
- `src/lib/tracing/instrumentation.ts` - OpenTelemetry configuration
- Automatic instrumentation for HTTP, database, and framework calls
- Custom spans for authentication operations

### 2. Signup Flow Tracing

The `SupabaseAuthenticationService.signUp()` method now includes:

```typescript
return tracer.startActiveSpan('auth.signup', async (span) => {
  span.setAttributes({
    'auth.email': email,
    'auth.auto_approve': autoApprove || false,
    'auth.has_metadata': !!metadata,
    'auth.has_database': !!this.database,
  });

  // ... signup logic with detailed events and error tracking
  
  if (profileError) {
    span.recordException(profileError as Error);
    // FIXED: Now returns error instead of silently continuing
    result.error = `User created but profile creation failed: ${profileError.message}`;
  }
});
```

### 3. Trace Structure

A successful signup creates this trace structure:

```
auth.signup
├── attempting_admin_user_creation
├── admin_user_created_successfully  
├── user_signed_in_successfully
├── attempting_profile_creation
└── profile_created_successfully
```

A failed profile creation shows:

```
auth.signup
├── attempting_admin_user_creation
├── admin_user_created_successfully
├── user_signed_in_successfully
├── attempting_profile_creation
└── [EXCEPTION] profile.creation_error
```

## Debugging with Honeycomb

### 1. View Signup Traces

1. Go to your Honeycomb dashboard
2. Filter by `service.name = aloft-app`
3. Look for spans with `name = auth.signup`

### 2. Common Issues to Look For

**Profile Creation Failures:**
- Look for `profile.creation_error` attribute
- Check database connection issues
- Verify user permissions on `profiles` table

**Database Connection Issues:**
- Look for PostgreSQL connection errors
- Check if `auth.has_database = false`
- Verify `DATABASE_URL` configuration

**Authentication Errors:**
- Look for `auth.admin_create_error` 
- Check Supabase service role permissions
- Verify `SUPABASE_SERVICE_ROLE_KEY`

### 3. Key Attributes to Monitor

- `auth.result_success` - Overall signup success
- `auth.has_user` - User creation success
- `auth.has_session` - Session creation success
- `profile.user_id` - User ID for profile creation
- `profile.creation_error` - Profile creation error details

## Running with Tracing

1. **Development:**
   ```bash
   npm run dev
   ```

2. **Check Console Output:**
   ```
   🔍 Initializing OpenTelemetry for aloft-app v1.0.0 (development)
   🔍 OpenTelemetry started successfully
   ```

3. **Test Signup Flow:**
   - Go to `/sign-up`
   - Fill out the form
   - Submit and watch for traces in Honeycomb

## Troubleshooting

### No Traces Appearing

1. Check `HONEYCOMB_API_KEY` is set
2. Verify `OTEL_SDK_DISABLED` is not `true`
3. Check console for OpenTelemetry initialization messages

### Profile Creation Still Failing

1. Check database connection in traces
2. Verify `profiles` table exists and has correct schema
3. Check RLS policies on `profiles` table
4. Verify user has permission to insert profiles

### Performance Impact

- Tracing adds minimal overhead (~1-2ms per request)
- Sampling can be configured if needed
- Disable in production with `OTEL_SDK_DISABLED=true`

## Modern Tracing Architecture

This setup uses the latest OpenTelemetry patterns:

- ✅ Modern semantic conventions (`ATTR_*` instead of `SEMRESATTRS_*`)
- ✅ Honeycomb OTLP HTTP exporter
- ✅ Next.js 15 compatible instrumentation
- ✅ Proper error handling and exception recording
- ✅ Structured attributes for easy querying
- ✅ Automatic and manual instrumentation combined

## Next Steps

1. **Add More Custom Spans:** Instrument other critical flows
2. **Set Up Alerts:** Create Honeycomb alerts for signup failures
3. **Add Metrics:** Track signup success rates and latency
4. **Sampling:** Configure sampling for high-traffic environments 