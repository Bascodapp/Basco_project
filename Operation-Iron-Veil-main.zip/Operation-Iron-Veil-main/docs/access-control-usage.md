# Using Authorization in Applications

## Getting Started

### 1. Initialize Authorization Context
```typescript
import { JWTAuthorizationContext } from "@/v2/auth/services/JWTAuthorizationContext";

// From server component or API route
const authContext = new JWTAuthorizationContext(jwtClaims);
```

### 2. Basic Authorization Checks
```typescript
// Check if user can perform an action
const canEdit = authContext.canPerformAction('projects', 'update');
const canDelete = authContext.canPerformAction('projects', 'delete');
const canCreate = authContext.canPerformAction('projects', 'insert');
```

## Common Usage Patterns

### UI Conditional Rendering
```typescript
function ProjectActions({ projectId }: { projectId: string }) {
  const authContext = useAuthContext();
  
  return (
    <div>
      {authContext.canPerformAction('projects', 'update') && (
        <EditButton projectId={projectId} />
      )}
      {authContext.canPerformAction('projects', 'delete') && (
        <DeleteButton projectId={projectId} />
      )}
    </div>
  );
}
```

### API Route Protection
```typescript
// app/api/projects/[id]/route.ts
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  const authContext = await getAuthContext(request);
  
  if (!authContext.canPerformAction('projects', 'delete')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  
  // Delete logic here
}
```

### Server Action Authorization
```typescript
"use server";

export async function updateProject(projectId: string, data: ProjectUpdateData) {
  const authContext = await getAuthContext();
  
  if (!authContext.canPerformAction('projects', 'update')) {
    throw new Error('Unauthorized');
  }
  
  // Update logic here
}
```

## Advanced Usage

### Resource-Specific Checks
```typescript
// Check specific resource access
const canAccessTeam = authContext.canAccessTeam(teamId);
const canManageTeam = authContext.canLeadTeam(teamId);
const canAccessDepartment = authContext.canAccessDepartment(deptId);
```

### Bulk Authorization
```typescript
// Filter resources by authorization
const authorizedProjects = projects.filter(project => {
  // RLS already filtered at DB level, but you can add app-specific logic
  return authContext.canPerformAction('projects', 'select');
});
```

### Context Information
```typescript
// Get user context
const userId = authContext.getUserId();
const companyId = authContext.getCompanyId();
const role = authContext.getCompanyRole();

// Get raw scopes for advanced scenarios
const scopes = authContext.getScopes();
const accessibleTeams = scopes.accessible_teams;
```

## Integration with Database

### Database queries are automatically filtered
```typescript
// RLS automatically applies - no additional filtering needed
const projects = await db.select().from(projectsTable);
// Only returns projects user can access
```

### Manual filtering (when needed)
```typescript
// Sometimes you need application-level filtering
const filteredProjects = await db
  .select()
  .from(projectsTable)
  .where(
    or(
      eq(projectsTable.createdBy, authContext.getUserId()),
      inArray(projectsTable.teamId, authContext.getScopes().manageable_teams)
    )
  );
```

## Error Handling

### Authorization Errors
```typescript
try {
  const authContext = new JWTAuthorizationContext(jwtClaims);
} catch (error) {
  if (error.message.includes('JWT claims must contain')) {
    // Handle malformed JWT
    redirect('/auth/sign-in');
  }
}
```

### Permission Denied
```typescript
if (!authContext.canPerformAction('projects', 'update')) {
  return (
    <div className="p-4 text-red-600">
      You don't have permission to edit this project.
    </div>
  );
}
```

## Performance Considerations

### Caching Authorization Context
```typescript
// Cache context per request
const authContext = useMemo(() => 
  new JWTAuthorizationContext(jwtClaims), 
  [jwtClaims]
);
```

### Batch Checks
```typescript
// Instead of multiple individual checks
const permissions = {
  canEdit: authContext.canPerformAction('projects', 'update'),
  canDelete: authContext.canPerformAction('projects', 'delete'),
  canCreate: authContext.canPerformAction('projects', 'insert'),
};
```

### Scope-Based Filtering
```typescript
// Use pre-calculated scopes for efficient filtering
const accessibleTeams = authContext.getScopes().accessible_teams;
const teamProjects = projects.filter(p => accessibleTeams.includes(p.teamId));
```

## Testing

### Mock Authorization Context
```typescript
// Test with specific permissions
const mockAuthContext = {
  canPerformAction: jest.fn().mockImplementation((resource, action) => {
    return resource === 'projects' && action === 'update';
  }),
  getUserId: () => 'test-user-id',
  getCompanyId: () => 'test-company-id',
};
```

### Integration Tests
```typescript
describe('Project Authorization', () => {
  it('should allow project owner to edit', async () => {
    const authContext = new JWTAuthorizationContext(ownerClaims);
    expect(authContext.canPerformAction('projects', 'update')).toBe(true);
  });
  
  it('should deny non-owner from editing', async () => {
    const authContext = new JWTAuthorizationContext(userClaims);
    expect(authContext.canPerformAction('projects', 'update')).toBe(false);
  });
});
``` 