# Storybook Component Testing Guide

## Overview

This guide covers best practices for testing React components in Storybook, based on real-world experience with complex form components and state management.

## Key Principles

### 1. Mock at the Right Layer

**❌ Don't mock complex internal structures:**
```typescript
// Avoid this - fragile and hard to maintain
useFormHook.mockReturnValue({
  form: {
    control: {} as any, // This will break
    formState: { errors: {} } as any,
    register: () => ({ /* complex mock */ }) as any,
  }
});
```

**✅ Mock at the data/action layer:**
```typescript
// Better - mock the server actions
import { signInAction } from '../interfaces/authentication-actions.mock';

// Loading state
signInAction.mockImplementation(() => new Promise(() => {}));

// Error state  
signInAction.mockImplementation(async () => ({
  success: false,
  error: 'Invalid credentials',
  isLoading: false,
}));
```

### 2. Test Component Behavior, Not Implementation

Focus on what users see and interact with, not internal state management.

**✅ Good tests:**
- Form fields are present and labeled correctly
- Buttons have proper disabled/enabled states
- Error messages display with correct styling
- Links navigate to correct paths
- Accessibility attributes are present

**❌ Avoid testing:**
- Internal hook state
- Complex form validation logic (test this in unit tests)
- Implementation details of third-party libraries

### 3. Use the Existing Mock Infrastructure

Check for existing mock files before creating new ones:
```typescript
// Use existing mocks
import { signInAction } from '../interfaces/authentication-actions.mock';
import { useSignInForm } from '../hooks/useAuthForms.mock';
```

## Story Organization

### Structure Stories by Use Case

```typescript
// =============================================================================
// DEFAULT STORIES - Basic component variations
// =============================================================================
export const Default: Story = { /* ... */ };
export const WithoutSignUpLink: Story = { /* ... */ };
export const CustomPaths: Story = { /* ... */ };

// =============================================================================
// STATE STORIES - Different component states
// =============================================================================
export const LoadingState: Story = { /* ... */ };
export const ErrorState: Story = { /* ... */ };

// =============================================================================
// INTERACTION STORIES - User interactions
// =============================================================================
export const FormInteraction: Story = { /* ... */ };
export const LinkNavigation: Story = { /* ... */ };

// =============================================================================
// ACCESSIBILITY STORIES - A11y verification
// =============================================================================
export const AccessibilityTest: Story = { /* ... */ };
```

### Keep Stories Focused

Each story should test one specific aspect:

```typescript
export const LoadingState: Story = {
  beforeEach: () => {
    // Simple, focused mock
    signInAction.mockImplementation(() => new Promise(() => {}));
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const user = userEvent.setup();
    
    // Trigger the state
    await user.type(canvas.getByLabelText('Email'), 'test@example.com');
    await user.type(canvas.getByLabelText('Password'), 'password123');
    await user.click(canvas.getByRole('button', { name: 'Sign In' }));
    
    // Verify the expected behavior
    expect(canvas.getByText('Signing in...')).toBeInTheDocument();
    expect(canvas.getByRole('button', { name: /signing in/i })).toBeDisabled();
  },
};
```

## Common Patterns

### Testing Form States

**Loading State:**
```typescript
beforeEach: () => {
  // Never resolving promise simulates loading
  serverAction.mockImplementation(() => new Promise(() => {}));
}
```

**Error State:**
```typescript
beforeEach: () => {
  // Quick resolution with error
  serverAction.mockImplementation(async () => ({
    success: false,
    error: 'Error message',
    isLoading: false,
  }));
}
```

### Accessibility Testing

Always include accessibility verification:
```typescript
export const AccessibilityTest: Story = {
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    
    // Check form structure
    const form = canvas.getByRole('button', { name: 'Submit' }).closest('form');
    expect(form).toBeInTheDocument();
    
    // Check input labels
    const emailInput = canvas.getByLabelText('Email');
    expect(emailInput).toHaveAttribute('type', 'email');
    expect(emailInput).toHaveAttribute('autocomplete', 'email');
    
    // Check button accessibility
    const submitButton = canvas.getByRole('button', { name: 'Submit' });
    expect(submitButton).toHaveAttribute('type', 'submit');
    
    // Check links
    const links = canvas.getAllByRole('link');
    links.forEach(link => {
      expect(link).toHaveAttribute('href');
    });
  },
};
```

## Troubleshooting

### Common Issues and Solutions

**Error: "Cannot read properties of undefined"**
- Usually caused by mocking internal library structures
- Solution: Mock at a higher level (actions, API calls)

**Tests are flaky or timing-dependent**
- Use `await` with user interactions
- Use `waitFor` for async state changes
- Consider if you're testing the right layer

**Mocks not working**
- Check import paths are correct
- Ensure mock files are properly structured
- Verify `beforeEach` is configured correctly

### When Tests Become Complex

If your story test becomes too complex, consider:
1. Breaking it into multiple focused stories
2. Moving complex logic to unit tests
3. Simplifying what you're testing
4. Using integration tests instead

## Example: Complete Form Component Story

```typescript
import type { Meta, StoryObj } from '@storybook/react';
import { action } from 'storybook/actions';
import { within, userEvent, expect } from 'storybook/test';
import { MyForm } from './MyForm';
import { submitAction } from '../actions/form-actions.mock';

const meta = {
  title: 'Components/MyForm',
  component: MyForm,
  parameters: {
    layout: 'centered',
  },
} satisfies Meta<typeof MyForm>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    onSuccess: action('form-success'),
    onError: action('form-error'),
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    
    // Test basic presence and accessibility
    expect(canvas.getByLabelText('Email')).toBeInTheDocument();
    expect(canvas.getByRole('button', { name: 'Submit' })).toBeInTheDocument();
  },
};

export const LoadingState: Story = {
  args: {
    onSuccess: action('form-success'),
    onError: action('form-error'),
  },
  beforeEach: () => {
    submitAction.mockImplementation(() => new Promise(() => {}));
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const user = userEvent.setup();
    
    await user.type(canvas.getByLabelText('Email'), 'test@example.com');
    await user.click(canvas.getByRole('button', { name: 'Submit' }));
    
    expect(canvas.getByText('Submitting...')).toBeInTheDocument();
    expect(canvas.getByRole('button', { name: /submitting/i })).toBeDisabled();
  },
};
```

## Best Practices Summary

1. **Mock at the data layer, not the UI layer**
2. **Test user-visible behavior, not implementation details**
3. **Keep stories focused on one aspect each**
4. **Always include accessibility testing**
5. **Use existing mock infrastructure**
6. **Prefer simple, readable tests over complex scenarios**
7. **When in doubt, move complex testing to unit or integration tests**

This approach leads to more maintainable, reliable, and meaningful component tests. 