# Access Control Documentation

Comprehensive guide to our unified access control system that provides consistent authorization at both database and application levels.

## System Overview

Our access control system uses a single source of truth (`authorization-rules.json`) to generate both database RLS policies and application-level authorization logic, ensuring perfect consistency across all security layers.

## Documentation Structure

### 📋 [System Overview](./access-control-overview.md)
High-level architecture and core concepts. **Start here** for understanding the system.

### 🛠️ [Working with Rules](./access-control-rules.md)
How to define, modify, and manage authorization rules. Essential for developers adding new features.

### 💻 [Using Authorization in Applications](./access-control-usage.md)
Practical guide for implementing authorization checks in your code. Required reading for all developers.

### 🔑 [JWT Flow and Organizational Context](./access-control-jwt-flow.md)
Deep dive into how JWT tokens are enhanced with organizational data and scopes.

### 🐛 [Debugging Access Control](./access-control-debugging.md)
Troubleshooting guide for common authorization issues and debugging tools.

### 🏗️ [Technical Architecture](./access-control-architecture.md)
Implementation details and design decisions. For staff engineers and system architects.

## Quick Reference

### Common Operations

```typescript
// Check permissions
const canEdit = authContext.canPerformAction('projects', 'update');

// Get user context
const userId = authContext.getUserId();
const companyId = authContext.getCompanyId();

// Check specific access
const canAccessTeam = authContext.canAccessTeam(teamId);
```

### Adding New Rules

1. Define in `authorization-rules.json`
2. Run `bun run codegen:auth-rules`
3. Apply migration `bun run db:migrate`

### Common Rule Patterns

```json
// Owner + Manager access
{
  "or": [
    { "userOwns": "created_by" },
    { "userManages": "team_id" }
  ]
}

// Hierarchical access
{
  "or": [
    { "userOwns": "user_id" },
    { "userAccesses": "team_id" },
    { "userAccesses": "department_id" }
  ]
}
```

## Key Benefits

- **Consistency**: Same rules generate both DB and app logic
- **Performance**: Pre-calculated JWT scopes avoid complex queries  
- **Maintainability**: Single source of truth for all authorization
- **Security**: Defense in depth with database + application layers

## Development Workflow

1. Define authorization requirements
2. Add rules to `authorization-rules.json`
3. Generate policies and application code
4. Implement UI/API authorization checks
5. Test at both database and application levels

## Support

### Common Issues
- User can't access expected resources → Check JWT claims and organizational memberships
- Database returns no results → Verify RLS policies and JWT token
- App/DB authorization mismatch → Compare rule engine vs. generated policies

### Debug Tools
- JWT inspector functions
- Authorization debugging utilities
- RLS policy testing commands
- Performance monitoring tools

## Next Steps

New to the system? Start with the [System Overview](./access-control-overview.md).

Adding a new feature? Check [Working with Rules](./access-control-rules.md) and [Using Authorization in Applications](./access-control-usage.md).

Debugging an issue? Go to [Debugging Access Control](./access-control-debugging.md). 