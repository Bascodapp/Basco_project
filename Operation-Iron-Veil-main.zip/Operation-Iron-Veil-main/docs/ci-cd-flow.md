# CI/CD Flow Documentation

This document explains how code moves from development to production, including our database setup and deployment processes.

## Overview

Our deployment process uses a **promotion model** where code moves through different environments before reaching customers. Each environment has its own database and configuration.

## System Architecture

```mermaid
graph TB
    subgraph "Development"
        Dev[Developer Machine]
        LocalDB[(Local Database)]
        Dev --- LocalDB
    end
    
    subgraph "Staging Environment"
        StagingApp[Staging App<br/>aloft-app-staging.tyelus.workers.dev]
        StagingDB[(Supabase Staging Database<br/>Replica of Production)]
        StagingApp --- StagingDB
    end
    
    subgraph "Production Preview"
        PreviewApp[Production Preview<br/>version-id-aloft-app-production.tyelus.workers.dev]
        ProductionDB[(Supabase Production Database<br/>Live Customer Data)]
        PreviewApp --- ProductionDB
    end
    
    subgraph "Production Live"
        ProdApp[Production App<br/>aloft-app.tyelus.workers.dev]
        ProdApp --- ProductionDB
    end
    
    subgraph "External Services"
        Cloudflare[Cloudflare Workers]
        Supabase[Supabase]
        Sentry[Sentry Error Tracking]
    end
    
    Dev --> StagingApp
    StagingApp --> PreviewApp
    PreviewApp --> ProdApp
    
    Cloudflare --> StagingApp
    Cloudflare --> PreviewApp
    Cloudflare --> ProdApp
    
    Supabase --> StagingDB
    Supabase --> ProductionDB
    
    style Dev fill:#e1f5fe
    style StagingApp fill:#fff3e0
    style PreviewApp fill:#f3e5f5
    style ProdApp fill:#e8f5e8
    style ProductionDB fill:#ffebee
    style StagingDB fill:#fff8e1
```

## Database Setup

### Staging Database
- **Purpose**: Safe environment for testing features
- **Data**: Copy of production data (anonymized)
- **Updates**: Refreshed weekly from production
- **Access**: Development team only

### Production Database
- **Purpose**: Live customer data
- **Data**: Real customer information
- **Backup**: Automated daily backups
- **Access**: Limited to production applications and authorized personnel

## Git Branch Flow

```mermaid
gitGraph
    commit id: "Initial"
    branch feature/auth-improvements
    checkout feature/auth-improvements
    commit id: "Add login form"
    commit id: "Add validation"
    checkout main
    merge feature/auth-improvements
    commit id: "Deploy to Preview" type: HIGHLIGHT
    branch release/v1.2.0
    checkout release/v1.2.0
    commit id: "Release v1.2.0" type: HIGHLIGHT
    checkout main
    merge release/v1.2.0
    commit id: "Production Live" type: HIGHLIGHT
    branch hotfix/critical-bug
    checkout hotfix/critical-bug
    commit id: "Fix critical bug"
    checkout main
    merge hotfix/critical-bug
    commit id: "Hotfix deployed"
```

## Environment Details

### 1. Local Development
- **URL**: `http://localhost:3000`
- **Database**: Local Supabase instance
- **Purpose**: Developer testing and feature development
- **Access**: Individual developers

### 2. Staging Environment
- **URL**: `https://aloft-app-staging.tyelus.workers.dev`
- **Database**: Supabase staging replica
- **Purpose**: Team testing and QA validation
- **Deployment**: Automatic on Pull Request creation
- **Access**: Development team, QA team, stakeholders

### 3. Production Preview
- **Alias URL**: `https://preview-aloft-app-production.tyelus.workers.dev`
- **Version URLs**: `https://[version-id]-aloft-app-production.tyelus.workers.dev`
- **URL Behavior**: **Alias URL stays the same, always points to latest version**
- **Database**: Production database (read-only for testing)
- **Purpose**: Final validation before going live
- **Deployment**: Automatic when code is merged to main
- **Access**: Limited team members for final approval
- **Bookmark**: Use the alias URL for consistent access

### 4. Production Live
- **URL**: `https://aloft-app.tyelus.workers.dev`
- **Database**: Production database (full access)
- **Purpose**: Live application for customers
- **Deployment**: Manual promotion from Production Preview
- **Access**: All customers and users

## Complete CI/CD Flow

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant PR as Pull Request
    participant Staging as Staging Environment
    participant Main as Main Branch
    participant Preview as Production Preview
    participant Release as Release Process
    participant Prod as Production
    participant Customer as Customers

    Dev->>PR: 1. Open PR
    PR->>Staging: 2. Auto-deploy to Staging
    Note over Staging: Team can test feature
    
    Dev->>PR: 3. Make updates
    PR->>Staging: 4. Re-deploy to Staging
    Note over Staging: Updated code available
    
    PR->>Main: 5. Merge PR (after approval)
    Main->>Preview: 6. Auto-deploy to Prod Preview
    Note over Preview: Code ready but not live
    
    Note over Main, Preview: Multiple PRs can accumulate here
    
    Dev->>Release: 7. Create Release v1.2.0
    Release->>Prod: 8. Deploy to Production
    Prod->>Customer: 9. Customers see changes!
    
    rect rgb(255, 240, 240)
        Note over Dev, Customer: Hotfix Flow (Emergency)
        Dev->>PR: Open hotfix PR
        PR->>Staging: Deploy to Staging
        PR->>Main: Merge hotfix
        Main->>Preview: Deploy to Prod Preview
        Dev->>Release: Create emergency release
        Release->>Prod: Deploy to Production
        Prod->>Customer: Customers see hotfix!
    end
```

## Deployment Process Details

### Pull Request Workflow
1. **Developer** creates feature branch
2. **Pull Request** opened - triggers staging deployment
3. **QA Team** tests on staging environment
4. **Code Review** by team members
5. **Merge** to main branch (requires approval)

### Production Deployment
1. **Main Branch** receives merged code
2. **Automatic** deployment to Production Preview
3. **Manual Approval** required for production
4. **Version Promotion** to live environment
5. **Customer Access** to new features

### Version Management
- Each deployment creates a **unique version ID**
- **Alias URL** always points to the latest version: `https://preview-aloft-app-production.tyelus.workers.dev`
- **Individual version URLs** remain accessible for testing specific versions
- **Rollback** capability to previous versions
- **Version History** tracking for auditing
- **Multiple Active Versions**: Several preview URLs can exist simultaneously
- **Version Cleanup**: Old versions can be deleted when no longer needed

#### URL Types
```
📌 Alias URL (always latest):     https://preview-aloft-app-production.tyelus.workers.dev
📦 Version URL (specific):        https://abc12345-aloft-app-production.tyelus.workers.dev
📦 Version URL (specific):        https://def67890-aloft-app-production.tyelus.workers.dev  
📦 Version URL (specific):        https://ghi11223-aloft-app-production.tyelus.workers.dev
```

**For QA Team**: Bookmark the alias URL - it always shows the latest version to test!

## Aliased Preview URLs

Our CI/CD system now uses **aliased preview URLs** to provide consistent, bookmarkable links for testing.

### Benefits
- **Consistent URL**: Always use `https://preview-aloft-app-production.tyelus.workers.dev` for testing
- **Automatic Updates**: The alias URL automatically points to the latest deployed version
- **Easy Bookmarking**: QA team can bookmark one URL instead of tracking changing version IDs
- **Stakeholder Friendly**: Share one URL that always has the latest features

### How It Works
1. **Code Merged**: When code is merged to main branch
2. **Version Created**: System creates a new version with unique ID
3. **Alias Updated**: The `preview` alias automatically points to the new version
4. **Testing**: Team uses the same alias URL to test the latest changes

### Multiple Environment Support
- **Production Preview**: `https://preview-aloft-app-production.tyelus.workers.dev`
- **Staging**: `https://staging-aloft-app-staging.tyelus.workers.dev` (if needed)
- **Feature Branches**: Can create temporary aliases for specific features

## Testing Strategy

### Staging Environment Testing
- **Automated Tests**: Run on every deployment
- **Manual Testing**: QA team validation
- **Feature Testing**: Stakeholder review
- **Integration Testing**: Third-party service validation

### Production Preview Testing
- **Final Approval**: Senior team members
- **Performance Testing**: Load and response time
- **Security Validation**: Access controls and permissions
- **Data Integrity**: Database operations verification

## Rollback Procedures

### Emergency Rollback
1. **Identify Issue**: Customer reports or monitoring alerts
2. **Immediate Action**: Promote previous working version
3. **Communication**: Notify team and stakeholders
4. **Investigation**: Determine root cause
5. **Fix and Redeploy**: Address issue and deploy fix

### Planned Rollback
1. **Issue Detection**: During preview testing
2. **Version Revert**: Switch back to previous version
3. **Issue Analysis**: Debug and fix problems
4. **Retest**: Validate fix in staging
5. **Redeploy**: Push corrected version

## Monitoring and Alerts

### Application Monitoring
- **Uptime Monitoring**: 99.9% availability target
- **Error Tracking**: Sentry integration for issue reporting
- **Performance Metrics**: Response time and load monitoring
- **User Analytics**: Usage patterns and feature adoption

### Database Monitoring
- **Query Performance**: Slow query detection
- **Connection Monitoring**: Database connectivity
- **Backup Verification**: Daily backup success confirmation
- **Data Integrity**: Consistency checks

## Team Responsibilities

### Development Team
- **Code Quality**: Write and review code
- **Feature Testing**: Local and staging validation
- **Documentation**: Update technical documentation
- **Bug Fixes**: Address issues and improvements

### QA Team
- **Feature Testing**: Comprehensive feature validation
- **Regression Testing**: Ensure existing features work
- **User Experience**: Validate user workflows
- **Bug Reporting**: Document and track issues

### Release Team
- **Version Management**: Coordinate releases
- **Production Deployment**: Manage live deployments
- **Rollback Management**: Handle emergency procedures
- **Communication**: Coordinate with all teams

## Common Commands

### For Developers
```bash
# Deploy to staging (automatic on PR)
git push origin feature/branch-name

# Upload version with custom alias
bun aloft worker version-upload --env production --preview-alias feature-auth

# Check deployment status
bun aloft worker version-list --env staging

# View logs
bun aloft logs --env staging
```

### For Release Team
```bash
# Deploy to production preview (automatic on merge)
git push origin main

# List recent versions with URLs
bun aloft worker version-list --env production --limit 5

# Promote specific version to production
bun aloft worker version-promote [version-id]

# Check production status
bun aloft worker deployment-status --env production

# Clean up old versions (optional)
bun aloft worker version-delete [old-version-id]
```

## Troubleshooting

### Common Issues
- **Deployment Failures**: Check build logs and dependencies
- **Database Issues**: Verify connection and permissions
- **Environment Configuration**: Confirm environment variables
- **Version Conflicts**: Ensure proper version management

### Getting Help
- **Technical Issues**: Contact development team
- **Deployment Problems**: Contact release team
- **Database Questions**: Contact database administrator
- **General Questions**: Use team communication channels