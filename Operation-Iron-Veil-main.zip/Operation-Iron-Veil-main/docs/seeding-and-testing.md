# Database Seeding & Testing Guide

This guide documents all the available database seeding scenarios, test users, their credentials, roles, and how to use them for testing your application, especially the `RoleBasedPage.tsx` component.

## 🚀 Quick Start

```bash
# Start local database
bun aloft db start

# Run database migrations
bun aloft db migrate

# Load startup scenario (recommended for testing)
bun aloft seed scenario startup

# Check what was created
bun aloft seed status
```

## 📋 Available Seeding Scenarios

### 1. **Startup** (`startup`) ⭐ **Recommended**

**Best for:** Comprehensive testing with realistic data generation

- **Description:** Complete startup environment with auto-generated realistic data
- **Companies:** 2 companies with full organizational structure
- **Users:** 14 users including role-based test users
- **Auto-Generation Features:**
  - **Departments:** 2 per company
  - **Groups:** 1 per company
  - **Teams:** 2 per group
  - **Programs:** 2 per portfolio (10 total)
  - **Projects:** 3 per program (30 total)
  - **Tasks:** 5 per project (150 total)
  - **Time Entries:** 10 per project, spanning 30 days back
  - **SBUs:** 4 per company (8 total)
  - **Master Data:** 10 time types, 10 instruments
- **Special:** ✨ Includes comprehensive organizational hierarchy and master data

```bash
bun aloft seed scenario startup
```

### 2. **Enterprise** (`enterprise`)

**Best for:** Testing large-scale scenarios and complex hierarchies

- **Description:** Large enterprise setup with multiple companies and complex hierarchies
- **Companies:** 3 companies (GlobalCorp Holdings, Innovation Labs, Regional Office)
- **Users:** 48+ users across all companies
- **Portfolios:** Multiple portfolios per company
- **Auto-Generation:** Configurable departments, groups, teams, programs, and projects

```bash
bun aloft seed scenario enterprise
```

### 3. **Consulting** (`consulting`)

**Best for:** Testing multi-client scenarios

- **Description:** Consulting firm with multiple client portfolios
- **Companies:** 1 consulting company with client-focused structure
- **Users:** 12+ users with consulting-specific roles
- **Portfolios:** 8 client portfolios
- **Auto-Generation:** Client-focused project structure

```bash
bun aloft seed scenario consulting
```

## 🏗️ Seeding Architecture

### **ScenarioGenerator System**

Our seeding system uses a modular `ScenarioGenerator` architecture:

- **Comprehensive Generation:** Creates realistic organizational structures
- **Master Data Management:** Automatically generates time types, instruments, and SBUs
- **Relationship Management:** Ensures proper foreign key relationships
- **Error Handling:** Robust error handling with detailed logging
- **Extensible:** Easy to add new generation patterns

### **Available Individual Seeders**

```bash
# Master Data
bun aloft seed time-types          # Generate time types
bun aloft seed instruments         # Generate instruments/equipment
bun aloft seed sbus               # Generate strategic business units

# Organizational Structure
bun aloft seed departments        # Generate departments
bun aloft seed groups            # Generate groups
bun aloft seed teams             # Generate teams

# Project Structure
bun aloft seed programs          # Generate programs
bun aloft seed projects          # Generate projects
bun aloft seed tasks             # Generate tasks

# Time Tracking
bun aloft seed time-entries      # Generate time entries

# Company Structure
bun aloft seed company-sbus      # Link SBUs to companies
```

## 👥 Test Users & Credentials

### **Default Password**

All seeded users use the password: **`Password123!`**

### **Startup Scenario Users**

#### **TechStart Inc** (`techstart`)

| Name         | Email                 | Role                     | Access Level               |
| ------------ | --------------------- | ------------------------ | -------------------------- |
| Alice CEO    | `alice@techstart.com` | System Administrator     | Full company access        |
| Bob CTO      | `bob@techstart.com`   | Portfolio Admin          | Technical portfolio access |
| Carol PM     | `carol@techstart.com` | Program Manager          | Program management access  |
| David Dev    | `david@techstart.com` | Project Developer        | Development project access |
| Eve Designer | `eve@techstart.com`   | Project Designer         | Design project access      |
| Frank QA     | `frank@techstart.com` | Project QA Engineer      | QA project access          |
| Grace BA     | `grace@techstart.com` | Project Business Analyst | Business analysis access   |

#### **InnovateCorp** (`innovatecorp`)

| Name           | Email                    | Role                     | Access Level               |
| -------------- | ------------------------ | ------------------------ | -------------------------- |
| Helen CEO      | `helen@innovatecorp.com` | System Administrator     | Full company access        |
| Ian CTO        | `ian@innovatecorp.com`   | Portfolio Admin          | Technical portfolio access |
| Jane PM        | `jane@innovatecorp.com`  | Program Manager          | Program management access  |
| Kevin Dev      | `kevin@innovatecorp.com` | Project Developer        | Development project access |
| Laura Designer | `laura@innovatecorp.com` | Project Designer         | Design project access      |
| Mike QA        | `mike@innovatecorp.com`  | Project QA Engineer      | QA project access          |
| Nina BA        | `nina@innovatecorp.com`  | Project Business Analyst | Business analysis access   |

## 🔐 System Roles & Permissions

### **Available System Roles** (16 total)

#### **Administrative Roles**

- **System Administrator:** Full access to all resources across all contexts
- **Portfolio Admin:** Portfolio management, program/project creation within portfolios
- **Program Manager:** Program management, project oversight within programs
- **Project Manager:** Full project management including team and budget management

#### **Leadership Roles**

- **Project Lead:** Project leadership, team coordination, limited management
- **Project Tech Lead:** Technical leadership within projects
- **Project Architect:** Technical architecture decisions within projects
- **Project Scrum Master:** Agile process management within projects

#### **Specialist Roles**

- **Project Developer:** Development work within assigned projects
- **Project Designer:** Design work within assigned projects
- **Project QA Engineer:** Quality assurance within projects
- **Project Business Analyst:** Business analysis within projects
- **Project Consultant:** Consulting work within projects

#### **General Roles**

- **Team Member:** Basic project access, task management
- **Developer:** General development access across projects
- **Viewer:** Read-only access across multiple contexts

### **Role Management Commands**

```bash
# List all available system roles
bun aloft seed list-available-roles

# Assign a role to a user
bun aloft seed assign-role \
  --user-id "user-uuid" \
  --role "Portfolio Admin" \
  --context-type "company" \
  --context-id "company-uuid"

# Remove a role from a user
bun aloft seed remove-role \
  --user-id "user-uuid" \
  --role "Portfolio Admin" \
  --context-type "company" \
  --context-id "company-uuid"

# List roles for a specific user
bun aloft seed list-user-roles \
  --user-id "user-uuid" \
  --context-type "company"

# Seed system roles (if not already present)
bun aloft seed roles
```

## 🧪 Testing Your RoleBasedPage Component

### **Testing Different Access Levels**

1. **System Administrator Access**

   ```bash
   # Sign in as: alice@techstart.com | Password123!
   # Should see all content and administrative features
   ```

2. **Portfolio Admin Access**

   ```bash
   # Sign in as: bob@techstart.com | Password123!
   # Should access portfolio administration features
   ```

3. **Program Manager Access**

   ```bash
   # Sign in as: carol@techstart.com | Password123!
   # Should access program management features
   ```

4. **Project Developer Access**

   ```bash
   # Sign in as: david@techstart.com | Password123!
   # Should access development project features
   ```

5. **Project Designer Access**
   ```bash
   # Sign in as: eve@techstart.com | Password123!
   # Should access design project features
   ```

### **RoleBasedPage Component Test Scenarios**

Your `RoleBasedPage.tsx` component can be tested with these scenarios:

#### **`PortfolioAdminPage`**

- ✅ **Access Granted:** System Administrator, Portfolio Admin
- ❌ **Access Denied:** Project Developer, Project Designer, Team Member

#### **`PortfolioManagerPage`**

- ✅ **Access Granted:** System Administrator, Portfolio Admin, Program Manager
- ❌ **Access Denied:** Project Developer, Project Designer, Team Member

#### **`PortfolioViewerPage`**

- ✅ **Access Granted:** System Administrator, Portfolio Admin, Program Manager, Viewer
- ❌ **Access Denied:** Users without portfolio view permissions

## 🛠️ CLI Usage

### **Database Management**

```bash
# Start/stop database
bun aloft db start
bun aloft db stop
bun aloft db reset --confirm

# Run migrations
bun aloft db migrate
```

### **Scenario Management**

```bash
# List available scenarios
bun aloft seed scenario:list

# Load specific scenario
bun aloft seed scenario startup
bun aloft seed scenario enterprise
bun aloft seed scenario consulting

# Load from custom JSON file
bun aloft seed from-json my-scenario.json

# Export current data to JSON
bun aloft seed export my-export.json
```

### **Individual Seeding Commands**

```bash
# Reset and clean database
bun aloft seed reset --confirm

# Generate base data
bun aloft seed generate --companies 2 --users-per-company 5

# Create specific entities
bun aloft seed company --name "Test Company" --slug "test-co"
bun aloft seed user --email "test@example.com" --first-name "Test" --last-name "User"

# Add organizational structure
bun aloft seed departments --count 3
bun aloft seed groups --count 2
bun aloft seed teams --count 4

# Add project structure
bun aloft seed programs --count 5
bun aloft seed projects --count 10
bun aloft seed tasks --count 50

# Add master data
bun aloft seed time-types
bun aloft seed instruments --count 15
bun aloft seed sbus --count 12

# Add time tracking data
bun aloft seed time-entries --entries-per-project 20 --days-back 60

# Check current status
bun aloft seed status
```

### **Role Management**

```bash
# System roles
bun aloft seed roles
bun aloft seed list-available-roles

# User role assignments
bun aloft seed assign-role --user-id "uuid" --role "Portfolio Admin" --context-type "company" --context-id "uuid"
bun aloft seed remove-role --user-id "uuid" --role "Portfolio Admin" --context-type "company" --context-id "uuid"
bun aloft seed list-user-roles --user-id "uuid"
```

## 🔍 Verification & Debugging

### **Check Seeded Data**

```bash
# Comprehensive status overview
bun aloft seed status

# Expected output for startup scenario:
# 📊 Current Seed Data Status:
# ═══════════════════════════════
# 📈 Summary:
#    🏢 Companies: 2
#    👥 Users: 14
#    📁 Portfolios: 5
#    🎯 Programs: 10
#    📝 Projects: 30 (expected)
#    ✅ Tasks: 150 (expected)
#    ⏰ Time Entries: 300 (expected)
#    👥 Groups: 2
#    🏈 Teams: 4
#    🏗️ SBUs: 10
#    🔗 Company-SBUs: 8
#    ⏰ Time Types: 10
#    🔬 Instruments: 10
#    🔐 System Roles: 16
```

### **Database Verification**

```bash
# Export for detailed inspection
bun aloft seed export debug-export.json

# Reset if needed
bun aloft seed reset --confirm
bun aloft seed scenario startup
```

### **Authentication Testing**

1. Navigate to `/sign-in`
2. Use any of the test emails above
3. Use password: `Password123!`
4. Test different pages with different user roles

## 📊 Company Structures

### **Startup Scenario Structure**

#### **TechStart Inc** (`techstart`)

- **Users:** 7 (CEO, CTO, PM, Developer, Designer, QA, BA)
- **Portfolios:** 2-3 portfolios with programs and projects
- **Organizational Structure:**
  - 2 Departments (Engineering, Product)
  - 1 Group per department
  - 2 Teams per group
- **Projects:** Auto-generated with realistic task distributions
- **SBUs:** 4 strategic business units linked to company

#### **InnovateCorp** (`innovatecorp`)

- **Users:** 7 (CEO, CTO, PM, Developer, Designer, QA, BA)
- **Portfolios:** 2-3 portfolios with programs and projects
- **Organizational Structure:** Similar to TechStart
- **Projects:** Auto-generated with comprehensive task structure
- **SBUs:** 4 strategic business units linked to company

### **Master Data Generated**

- **Time Types:** 10 types (Development, Design, Testing, Meetings, etc.)
- **Instruments:** 10 equipment/tools entries
- **SBUs:** 10 total strategic business units
- **Company-SBU Links:** 8 relationships between companies and SBUs

## 🚨 Troubleshooting

### **Common Issues**

1. **"Tenant or user not found"**

   ```bash
   bun aloft db start
   bun aloft db migrate
   ```

2. **"System roles not found"**

   ```bash
   bun aloft seed roles
   ```

3. **"Permission denied"**

   - Check user has correct role assignment
   - Verify role has required permissions
   - Check context (company/portfolio) access

4. **"Database constraint errors"**

   ```bash
   bun aloft seed reset --confirm
   bun aloft seed scenario startup
   ```

5. **"Incomplete data generation"**
   - Check logs for specific errors
   - Verify all required seeders are implemented
   - Try individual seeding commands to isolate issues

### **Reset Everything**

```bash
bun aloft seed reset --confirm
bun aloft seed scenario startup
```

### **Debug Individual Components**

```bash
# Test specific seeders
bun aloft seed time-types
bun aloft seed instruments
bun aloft seed sbus
bun aloft seed departments
bun aloft seed programs
```

## 🎯 Advanced Usage

### **Custom JSON Scenarios**

Create custom scenario files with this structure:

```json
{
  "name": "My Custom Scenario",
  "description": "Custom test scenario",
  "companies": [
    {
      "name": "My Company",
      "slug": "my-company",
      "userCount": 5,
      "portfolioCount": 2,
      "autoGenerate": {
        "departments": 2,
        "groups": 1,
        "teams": 2,
        "programs": 3,
        "projects": 5,
        "tasks": 10,
        "timeEntries": 20,
        "daysBack": 30,
        "sbus": 3
      }
    }
  ]
}
```

### **Extending the System**

The seeding system is built with extensibility in mind:

- Add new seeders by implementing the seeder interface
- Extend ScenarioGenerator for new generation patterns
- Add new CLI commands in the seed command structure
- Customize auto-generation parameters per scenario

## 📝 Notes

- All passwords are `Password123!` for development
- System roles are automatically seeded when creating companies
- Role assignments are context-aware (global, company, portfolio, program, project levels)
- The `RoleBasedPage` component checks both roles AND permissions
- ScenarioGenerator creates realistic relationships and hierarchies
- Master data is automatically generated for comprehensive testing
- Time entries span realistic date ranges for testing time tracking features

---

**Happy Testing! 🎉**

For more information, check the CLI help:

```bash
bun aloft --help
bun aloft seed --help
bun aloft seed scenario --help
```
