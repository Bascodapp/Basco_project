# Access Control System Overview

## Architecture

Single source of truth for authorization rules generates both database RLS policies and application-level checks.

## Core Components

### 1. Authorization Rules (`authorization-rules.json`)
- JSON schema defining all access control rules
- Declarative conditions using `userOwns`, `userAccesses`, `userManages`
- Maps to both database and application authorization

### 2. Generated RLS Policies 
- Drizzle policies auto-generated from rules
- Uses JWT claims with pre-calculated scopes
- Enforces security at database level

### 3. JWT Claims Enhancement
- `custom_access_token_hook` adds organizational context
- Pre-calculates accessible/manageable resources
- Optimizes both RLS and application checks

### 4. Application Authorization
- `JWTAuthorizationContext` uses same rule engine
- Consistent decisions with database policies
- Runtime checks for UI/API logic

## Key Benefits

- **Consistency**: Same rules generate both DB and app logic
- **Performance**: Pre-calculated JWT scopes avoid complex queries
- **Maintainability**: Single source of truth for all authorization
- **Security**: Defense in depth with database + application layers

## Rule Evaluation Flow

1. User authenticates → JWT enhanced with organizational context
2. Database queries → RLS policies evaluate using JWT scopes
3. Application logic → Rule engine evaluates using same JWT claims
4. Both layers return identical authorization decisions

## Quick Start

```typescript
// Application authorization check
const authContext = new JWTAuthorizationContext(jwtClaims);
const canEdit = authContext.canPerformAction('projects', 'update');

// Database automatically enforces via RLS
const projects = await db.select().from(projectsTable); // Only returns authorized records
```

## Next Steps

- [Working with Rules](./access-control-rules.md)
- [Using Authorization in Applications](./access-control-usage.md)
- [JWT Flow and Organizational Context](./access-control-jwt-flow.md)
- [Debugging Access Control](./access-control-debugging.md) 