# Access Control Architecture

## Design Principles

### Single Source of Truth
- All authorization rules defined in `authorization-rules.json`
- Same rules generate both database policies and application logic
- Eliminates divergence between security layers

### Performance-First
- Pre-calculated JWT scopes avoid complex database joins
- Fast array membership checks in RLS policies
- Hierarchical permissions flattened into accessible arrays

### Defense in Depth
- Database-level security via RLS policies
- Application-level authorization for UI/UX
- Both layers use identical rule evaluation

## System Components

### 1. Rule Definition (`authorization-rules.json`)
```json
{
  "resource": "projects",
  "action": "select", 
  "conditions": {
    "or": [
      { "userOwns": "created_by" },
      { "userAccesses": "team_id" }
    ]
  }
}
```

### 2. Code Generation
- `AuthorizationRuleEngine` processes JSON rules
- Generates Drizzle RLS policies with SQL expressions
- Creates application-level authorization logic

### 3. JWT Enhancement
- `custom_access_token_hook` enriches JWT claims
- Calculates organizational context and scopes
- Optimizes for both RLS and application use

### 4. Runtime Authorization
- `JWTAuthorizationContext` provides consistent API
- Same rule engine used for generation and evaluation
- Guarantees identical decisions at all layers

## Rule Processing Flow

1. **Rule Definition**: Engineer defines authorization rules in JSON
2. **Code Generation**: Rules compiled to SQL policies and TypeScript
3. **JWT Enhancement**: User context calculated and cached in JWT
4. **Policy Evaluation**: RLS policies use JWT scopes for authorization
5. **Application Checks**: Same JWT claims used for UI/API logic

## JWT Scope Calculation

### Hierarchical Access
```sql
-- Teams accessible through hierarchy:
-- 1. Direct team membership
-- 2. Group membership (any role)  
-- 3. Department membership (any role)
```

### Management Rights
```sql
-- Teams manageable through leadership:
-- 1. Direct team leadership
-- 2. Group leadership
-- 3. Department leadership  
```

### Flattened Arrays
```json
{
  "accessible_teams": ["team-1", "team-2", "team-3"],
  "manageable_teams": ["team-1"]
}
```

## RLS Policy Generation

### Condition Translation
```json
// Rule condition
{ "userAccesses": "team_id" }

// Generated SQL
team_id = ANY(
  SELECT jsonb_array_elements_text(
    COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
  )::uuid
)
```

### Performance Optimization
- Array membership checks are O(n) but n is small
- Avoids complex joins with organizational tables
- Pre-calculated scope arrays enable fast evaluation

## Application Integration

### Context Creation
```typescript
const authContext = new JWTAuthorizationContext(jwtClaims);
```

### Authorization Checks
```typescript
// Uses same rule engine that generates policies
const canEdit = authContext.canPerformAction('projects', 'update');
```

### Consistency Guarantee
- Application and database use identical JWT claims
- Same rule engine evaluates both layers
- Impossible for authorization to diverge

## Error Handling Strategy

### JWT Validation
- Strict validation of required claims
- Graceful handling of expired/invalid tokens
- Automatic redirect to authentication

### Authorization Failures
- Clear error messages for debugging
- Structured logging for production monitoring
- Fallback to secure defaults (deny access)

### Database Errors
- RLS policies fail closed (no access)
- Application catches and handles gracefully
- Monitoring alerts for systematic issues

## Monitoring & Observability

### Performance Metrics
- JWT size monitoring
- Authorization check latency
- Database query performance

### Security Auditing
- All authorization decisions logged
- Failed access attempts tracked
- Organizational changes monitored

### Debug Capabilities
- JWT claims inspection
- Rule evaluation tracing
- RLS policy testing tools

## Scalability Considerations

### JWT Size Management
- Monitor token size growth
- Implement scope pruning for large organizations
- Consider JWT compression for extreme cases

### Database Performance
- Index on commonly accessed fields
- Monitor RLS policy query plans
- Optimize scope array operations

### Caching Strategy
- JWT valid for configured duration
- Balance security vs. performance
- Implement selective cache invalidation

## Security Features

### Principle of Least Privilege
- Default deny for all resources
- Explicit grants required for access
- Hierarchical permissions with clear boundaries

### Company Isolation
- Strong company-level boundaries
- Prevents cross-company data leakage
- Enforced at database and application levels

### Role-Based Access
- Granular role definitions
- Hierarchical permission inheritance
- Clear separation of access vs. management rights

## Development Workflow

### Adding New Resources
1. Define authorization rules in JSON
2. Generate policies and migrations
3. Update application code
4. Test authorization at all layers

### Modifying Permissions
1. Update rules in single location
2. Regenerate all dependent code
3. Deploy with database migration
4. Verify consistent behavior

### Debugging Issues
1. Inspect JWT claims and scopes
2. Test RLS policies directly
3. Compare application vs. database decisions
4. Use provided debugging tools

## Best Practices

### Rule Design
- Keep rules simple and readable
- Use consistent naming conventions
- Document complex authorization logic

### Performance
- Monitor JWT size and performance
- Use scopes for efficient filtering
- Avoid complex rule conditions

### Security
- Regular security audits
- Principle of least privilege
- Defense in depth approach

### Maintainability
- Single source of truth
- Automated code generation
- Comprehensive testing strategy 