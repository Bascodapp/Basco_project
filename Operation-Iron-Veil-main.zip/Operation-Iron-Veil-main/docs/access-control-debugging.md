# Debugging Access Control

## Common Issues & Solutions

### 1. User Can't Access Expected Resources

#### Check JWT Claims
```typescript
// Inspect JWT claims in browser devtools or server logs
const authContext = new JWTAuthorizationContext(jwtClaims);
console.log('JWT Claims:', authContext.getClaims());
console.log('Scopes:', authContext.getScopes());
```

#### Verify Organizational Context
```sql
-- Check user's organizational memberships
SELECT get_user_organizational_context('user-id-here');
```

#### Common Causes:
- User not added to required team/department
- Team/department marked as inactive
- JWT token expired or not refreshed
- Company isolation preventing access

### 2. Database Returns No Results

#### Check RLS Policies
```sql
-- Test RLS policy directly
SET ROLE authenticated;
SET request.jwt.claims = '{"sub": "user-id", "company_id": "company-id", "scopes": {...}}';
SELECT * FROM projects WHERE id = 'project-id';
```

#### Verify Policy Generation
```typescript
// Check generated policies match expectations
import { projectsPolicies } from '@/lib/db/schema/policies/projects.policies.generated';
console.log('Generated policies:', projectsPolicies);
```

### 3. Application vs Database Mismatch

#### Compare Decisions
```typescript
// Check if app and DB give same result
const authContext = new JWTAuthorizationContext(jwtClaims);
const appDecision = authContext.canPerformAction('projects', 'update');

// Then check what database returns
const dbResults = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
console.log('App allows:', appDecision);
console.log('DB returns:', dbResults.length > 0);
```

## Debugging Tools

### JWT Inspector
```typescript
function debugJWT(claims: JWTClaims) {
  console.log('=== JWT Debug Info ===');
  console.log('User ID:', claims.sub);
  console.log('Company ID:', claims.company_id);
  console.log('Expiry:', new Date(claims.exp * 1000));
  console.log('Organizational Context:', claims.organizational_context);
  console.log('Scopes:', claims.scopes);
  console.log('=====================');
}
```

### Authorization Inspector
```typescript
function debugAuthorization(authContext: JWTAuthorizationContext, resource: string, action: string) {
  console.log('=== Authorization Debug ===');
  console.log(`Resource: ${resource}, Action: ${action}`);
  console.log('Decision:', authContext.canPerformAction(resource, action));
  console.log('User ID:', authContext.getUserId());
  console.log('Company ID:', authContext.getCompanyId());
  console.log('Company Role:', authContext.getCompanyRole());
  console.log('Raw Scopes:', authContext.getScopes());
  console.log('==========================');
}
```

### Rule Engine Debugging
```typescript
// Enable rule engine debug mode
const ruleEngine = new AuthorizationRuleEngine({ debug: true });
const decision = ruleEngine.canPerformAction('projects', 'update', jwtClaims);
// Will log rule evaluation steps
```

## Database Debugging

### Check RLS is Enabled
```sql
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' AND tablename = 'projects';
```

### View Applied Policies
```sql
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual 
FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'projects';
```

### Test Policy Conditions
```sql
-- Test specific policy conditions
SELECT 
  id,
  created_by = auth.uid() as user_owns,
  team_id = ANY(
    SELECT jsonb_array_elements_text(
      COALESCE(auth.jwt()->'scopes'->'accessible_teams', '[]'::jsonb)
    )::uuid
  ) as team_accessible
FROM projects 
WHERE id = 'project-id';
```

## Performance Debugging

### Slow Authorization Checks
```typescript
// Time authorization checks
console.time('auth-check');
const canEdit = authContext.canPerformAction('projects', 'update');
console.timeEnd('auth-check');
```

### Database Query Analysis
```sql
-- Analyze RLS query performance
EXPLAIN ANALYZE SELECT * FROM projects WHERE id = 'project-id';
```

### JWT Scope Size
```typescript
// Check if JWT is too large
const jwtString = JSON.stringify(jwtClaims);
console.log('JWT size:', jwtString.length, 'characters');
if (jwtString.length > 4096) {
  console.warn('JWT may be too large, consider optimizing scopes');
}
```

## Common Debugging Scenarios

### User Reports "Access Denied"
1. Check JWT claims and scopes
2. Verify user's organizational memberships
3. Test specific resource access
4. Compare app vs DB decisions

### Database Returns Empty Results
1. Check RLS policies are applied
2. Verify JWT token in request
3. Test policy conditions manually
4. Check for company isolation issues

### Inconsistent Behavior
1. Compare rule engine vs generated policies
2. Check for cached authorization contexts
3. Verify JWT token refresh
4. Test with different user roles

## Logging Configuration

### Development Logging
```typescript
// Add to development environment
if (process.env.NODE_ENV === 'development') {
  console.log('Authorization Decision:', {
    resource,
    action,
    decision: authContext.canPerformAction(resource, action),
    userId: authContext.getUserId(),
    scopes: authContext.getScopes()
  });
}
```

### Production Debugging
```typescript
// Add structured logging for production debugging
import { logger } from '@/lib/logger';

logger.debug('authorization_check', {
  resource,
  action,
  decision,
  userId: authContext.getUserId(),
  companyId: authContext.getCompanyId(),
  timestamp: new Date().toISOString()
});
```

## Performance Monitoring

### Track Authorization Performance
```typescript
// Monitor authorization check performance
const authStart = performance.now();
const decision = authContext.canPerformAction(resource, action);
const authTime = performance.now() - authStart;

if (authTime > 10) { // Log slow checks
  console.warn('Slow authorization check:', {
    resource,
    action,
    time: authTime,
    decision
  });
}
``` 