// This file configures the initialization of Sentry for edge runtime.
// The config you add here will be used whenever a page or API route is handled by the edge runtime.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/

import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: "https://4b5dc1f08be1c4d110b7006ff803bc03@o4509549067370496.ingest.us.sentry.io/4509549068025857",

  // Define how likely traces are sampled. Adjust this value in production, or use tracesSampler for greater control.
  tracesSampleRate: 1,

  // Setting this option to true will print useful information to the console while you're setting up Sentry.
  debug: false,

  // Configure transaction sampling
  beforeSendTransaction(transaction) {
    // Always trace authentication-related transactions
    if (transaction.transaction?.includes('auth') || 
        transaction.transaction?.includes('signin') ||
        transaction.transaction?.includes('signup')) {
      return transaction;
    }
    return transaction;
  },

  // Add custom tags
  beforeSend(event) {
    if (event.transaction?.includes('auth') || 
        event.tags?.category === 'authentication') {
      event.tags = {
        ...event.tags,
        feature: 'authentication',
        flow: 'signin',
        runtime: 'edge',
      };
    }
    return event;
  },
});
