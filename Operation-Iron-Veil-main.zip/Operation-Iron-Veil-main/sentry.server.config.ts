// This file configures the initialization of Sentry on the server.
// The config you add here will be used whenever the server handles a request.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/

import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: "https://4b5dc1f08be1c4d110b7006ff803bc03@o4509549067370496.ingest.us.sentry.io/4509549068025857",

  // Define how likely traces are sampled. Adjust this value in production, or use tracesSampler for greater control.
  tracesSampleRate: 1,

  // Setting this option to true will print useful information to the console while you're setting up Sentry.
  debug: false,

  // Enhanced tracing configuration for authentication flows
  integrations: [
    // Enable automatic instrumentation of Node.js APIs
    Sentry.httpIntegration({
      breadcrumbs: true,
    }),
  ],

  // Configure which transactions to trace
  beforeSendTransaction(transaction) {
    // Always trace authentication-related transactions
    if (transaction.transaction?.includes('auth') || 
        transaction.transaction?.includes('signin') ||
        transaction.transaction?.includes('signup')) {
      return transaction;
    }
    return transaction;
  },

  // Add custom tags for better filtering
  beforeSend(event) {
    // Tag authentication-related events
    if (event.transaction?.includes('auth') || 
        event.tags?.category === 'authentication') {
      event.tags = {
        ...event.tags,
        feature: 'authentication',
        flow: 'signin',
      };
    }
    return event;
  },
});
