import { defineConfig } from "allure";

export default defineConfig({
  name: "Aloft Test Report",
  output: "./allure-report",
  plugins: {
    awesome: {
      options: {
        singleFile: false,
        reportLanguage: "en",
        reportName: "Aloft - E2E & Integration Test Results",
        open: false
      },
    },
  },
}); 