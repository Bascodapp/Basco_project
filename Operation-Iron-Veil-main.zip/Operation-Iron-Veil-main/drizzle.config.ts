import type { Config } from "drizzle-kit";

export default {
  schema: "./src/lib/db/schema/index.ts",
  out: "./drizzle/migrations",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL!,
    ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: false } : false,
  },
  verbose: true,
  strict: true,
  // Enable role management for RLS
  entities: {
    roles: {
      // Use Supabase's predefined roles
      provider: "supabase",
    },
  },
} satisfies Config;
